import { spawn } from "node:child_process";
import { access, mkdir, writeFile } from "node:fs/promises";
import { basename, delimiter, join, resolve } from "node:path";
import puppeteer, { type Browser, type Page } from "puppeteer-core";

const DEBUG_URL = "http://127.0.0.1:9222";
const PROFILE = resolve("data", "chrome-profile");
const MAX_DUMP_BYTES = 200 * 1024;
const LOGIN_MESSAGE = "Đăng nhập Google trong cửa sổ Chrome vừa mở, rồi bấm Kết nối lại";
const KNOWN_ERRORS = [
  LOGIN_MESSAGE,
  "Không tìm thấy Chrome.",
  "Không mở được Chrome.",
  "Không tạo được hồ sơ Chrome",
  "Chrome chưa khởi động được.",
  "Chưa kết nối được với Chrome.",
  "Không mở được Search Console.",
  "Không tìm thấy tab Search Console",
  "Không lưu được bản chụp trang"
];
export const SELECTORS = {
  labels: {
    clicks: ["total clicks", "tổng số lượt nhấp", "tổng lượt nhấp", "lượt nhấp"],
    impressions: ["total impressions", "tổng số lượt hiển thị", "tổng lượt hiển thị", "lượt hiển thị"],
    ctr: ["average ctr", "ctr trung bình", "ctr"],
    position: ["average position", "vị trí trung bình"]
  },
  columns: {
    clicks: ["clicks", "lượt nhấp"],
    impressions: ["impressions", "lượt hiển thị"],
    ctr: ["ctr"],
    position: ["position", "vị trí"]
  },
  tabs: {
    queries: ["queries", "truy vấn"],
    pages: ["pages", "trang"],
    devices: ["devices", "thiết bị"],
    countries: ["countries", "quốc gia"],
    searchAppearance: ["search appearance", "giao diện tìm kiếm"]
  },
  permission: ["không có quyền", "quyền truy cập", "don't have access", "permission", "verify"],
  selectors: {
    tab: "button,[role='tab'],a,[role='button']",
    row: "tr,[role='row']",
    cell: "th,td,[role='cell'],[role='columnheader']",
    aria: "[aria-label]"
  }
} as const;
let launching: Promise<Browser> | undefined;

export type StatsConnection = { connected: boolean; message: string };
export type MetricRow = { key: string; clicks: number | null; impressions: number | null; ctr: number | null; position: number | null };
export type StatNumber = { value: number; display: string };
export type StatsData = {
  connected: boolean;
  site: string;
  selectedKey: string;
  green: boolean;
  period: string;
  summary: { clicks: StatNumber | null; impressions: StatNumber | null; ctr: StatNumber | null; position: StatNumber | null };
  queries: MetricRow[];
  pages: MetricRow[];
  devices: MetricRow[];
  countries: MetricRow[];
  searchAppearance: MetricRow[];
  ga: Array<{ label: string; value: string }>;
  gaDiagnostic?: string;
  messages: string[];
  diagnostic?: string;
};
type DumpPage = { url: string; title: string; text: string; aria: string[]; tables: string[] };

function chromeCandidates(): string[] {
  const home = process.env.USERPROFILE || process.env.HOME || "";
  return [
    process.env.CHROME_PATH,
    "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
    "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
    "C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe",
    "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe",
    home ? join(home, "AppData/Local/Google/Chrome/Application/chrome.exe") : "",
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
    "/usr/bin/google-chrome",
    "/usr/bin/google-chrome-stable",
    "/usr/bin/chromium",
    "/usr/bin/chromium-browser",
    "/snap/bin/chromium",
    ...(process.env.PATH || "").split(delimiter).flatMap(directory =>
      ["chrome", "google-chrome", "chromium", "msedge"].map(name => join(directory, name)))
  ].filter((path): path is string => Boolean(path));
}

async function findChrome(): Promise<string> {
  for (const candidate of chromeCandidates()) {
    try { await access(candidate); return candidate; } catch { /* Kiểm tra đường dẫn Chrome tiếp theo. */ }
  }
  throw new Error("Không tìm thấy Chrome. Có thể đặt đường dẫn Chrome trong CHROME_PATH.");
}

async function debugVersion(): Promise<boolean> {
  try {
    const response = await fetch(`${DEBUG_URL}/json/version`, { signal: AbortSignal.timeout(1500) });
    if (!response.ok) return false;
    const version = await response.json() as { webSocketDebuggerUrl?: string };
    return Boolean(version.webSocketDebuggerUrl);
  } catch {
    return false;
  }
}

async function startChrome(): Promise<void> {
  const executable = await findChrome();
  try { await mkdir(PROFILE, { recursive: true }); } catch {
    throw new Error("Không tạo được hồ sơ Chrome trong thư mục data.");
  }
  await new Promise<void>((resolveSpawn, rejectSpawn) => {
    const child = spawn(executable, [
      "--remote-debugging-port=9222",
      `--user-data-dir=${PROFILE}`,
      "https://search.google.com/search-console"
    ], { detached: true, stdio: "ignore", windowsHide: false });
    child.once("error", rejectSpawn);
    child.once("spawn", () => {
      child.unref();
      resolveSpawn();
    });
  }).catch(() => {
    throw new Error("Không mở được Chrome. Kiểm tra đường dẫn Chrome trên máy.");
  });
  for (let attempt = 0; attempt < 30; attempt += 1) {
    if (await debugVersion()) return;
    await new Promise(resolveDelay => setTimeout(resolveDelay, 500));
  }
  throw new Error("Chrome chưa khởi động được. Kiểm tra Chrome rồi bấm Kết nối lại.");
}

async function connectBrowser(): Promise<Browser> {
  if (!launching) {
    launching = (async () => {
      if (!(await debugVersion())) await startChrome();
      try {
        return await puppeteer.connect({ browserURL: DEBUG_URL });
      } catch {
        throw new Error("Chưa kết nối được với Chrome. Mở lại Chrome rồi bấm Kết nối lại.");
      }
    })().finally(() => { launching = undefined; });
  }
  return launching;
}

async function googlePages(browser: Browser, host: string): Promise<Page[]> {
  const pages = await browser.pages();
  return pages.filter(page => {
    try { return new URL(page.url()).hostname.toLowerCase() === host; } catch { return false; }
  });
}

async function loginRequired(browser: Browser): Promise<boolean> {
  const pages = await browser.pages();
  let productPage = false;
  let authenticatedProductPage = false;
  for (const page of pages) {
    try {
      const current = new URL(page.url());
      if (current.hostname === "accounts.google.com") {
        continue;
      }
      if (!/^(search|analytics)\.google\.com$/i.test(current.hostname)) continue;
      productPage = true;
      const loginLink = await page.evaluate(() => [...document.querySelectorAll("a[href]")]
        .some(link => {
          try {
            const target = new URL((link as HTMLAnchorElement).href);
            return target.hostname === "accounts.google.com" && /servicelogin|signin/i.test(target.pathname);
          }
          catch { return false; }
        }));
      if (!loginLink) authenticatedProductPage = true;
    } catch { /* Bỏ qua tab đóng trong lúc kiểm tra. */ }
  }
  return !productPage || !authenticatedProductPage;
}

async function ensureSearchConsolePage(browser: Browser): Promise<void> {
  const pages = await browser.pages();
  if (pages.some(page => {
    try { return new URL(page.url()).hostname === "search.google.com"; } catch { return false; }
  })) return;
  try {
    const page = await browser.newPage();
    await page.goto("https://search.google.com/search-console", { waitUntil: "domcontentloaded", timeout: 20_000 });
  } catch {
    throw new Error("Không mở được Search Console. Kiểm tra kết nối mạng rồi bấm Kết nối lại.");
  }
}

function friendlyError(error: unknown, fallback: string): Error {
  const message = error instanceof Error ? error.message : "";
  return new Error(KNOWN_ERRORS.some(known => message.startsWith(known)) ? message : fallback);
}

export async function connectStats(): Promise<StatsConnection> {
  let browser: Browser;
  try { browser = await connectBrowser(); } catch (error) {
    throw friendlyError(error, "Không kết nối được với Chrome.");
  }
  try {
    await ensureSearchConsolePage(browser);
    return await loginRequired(browser)
      ? { connected: false, message: LOGIN_MESSAGE }
      : { connected: true, message: "Đã kết nối Chrome. Tài khoản Google đã đăng nhập." };
  } catch (error) {
    throw friendlyError(error, "Không kiểm tra được trạng thái đăng nhập Google.");
  } finally {
    browser.disconnect();
  }
}

function truncateUtf8(value: string, maximumBytes: number): string {
  let output = "";
  let used = 0;
  for (const character of value) {
    const size = Buffer.byteLength(character, "utf8");
    if (used + size > maximumBytes) break;
    output += character;
    used += size;
  }
  return output;
}

async function pageDump(page: Page): Promise<DumpPage> {
  return page.evaluate(() => ({
    url: location.href,
    title: document.title,
    text: document.body?.innerText || "",
    aria: [...document.querySelectorAll("[aria-label]")].map(element =>
      `${element.getAttribute("aria-label") || ""} [${element.tagName.toLowerCase()}]`),
    tables: [...document.querySelectorAll("table,[role='table'],[role='grid'],[role='treegrid']")]
      .map(element => element.outerHTML)
  }));
}

function formatDump(data: DumpPage): string {
  return [
    `URL\n${data.url}`,
    `document.title\n${data.title}`,
    `innerText hiển thị\n${data.text}`,
    `Phần tử có aria-label\n${data.aria.join("\n")}`,
    `HTML vùng bảng số liệu\n${data.tables.join("\n") || "(Không tìm thấy bảng HTML hoặc vùng có vai trò bảng/lưới.)"}`
  ].join("\n\n");
}

export async function dumpGooglePages(): Promise<{ files: string[]; message: string }> {
  let browser: Browser;
  try { browser = await connectBrowser(); } catch (error) {
    throw friendlyError(error, "Không kết nối được với Chrome.");
  }
  try {
    if (await loginRequired(browser)) throw new Error(LOGIN_MESSAGE);
    const targets = [
      { host: "search.google.com", file: resolve("data", "dump-gsc.txt") },
      { host: "analytics.google.com", file: resolve("data", "dump-ga.txt") }
    ];
    const files: string[] = [];
    for (const target of targets) {
      const pages = await googlePages(browser, target.host);
      if (!pages.length) continue;
      const contents: string[] = [];
      for (const page of pages) contents.push(formatDump(await pageDump(page)));
      const bounded = truncateUtf8(contents.join("\n\n---\n\n"), MAX_DUMP_BYTES);
      await mkdir(resolve("data"), { recursive: true });
      await writeFile(target.file, bounded, "utf8");
      files.push(basename(target.file));
    }
    if (!files.length) throw new Error("Không tìm thấy tab Search Console hoặc Analytics đang mở trong Chrome.");
    return { files, message: `Đã lưu ${files.map(file => file.split(/[\\/]/).pop()).join(" và ")} trong thư mục data.` };
  } catch (error) {
    throw friendlyError(error, "Không lưu được bản chụp trang. Kiểm tra tab Google và thư mục data.");
  } finally {
    browser.disconnect();
  }
}

export function parseSo(input: string): number | null {
  const compact = input.trim().replace(/\s+/g, "");
  const suffix = /(tr|[knm])%?$/i.exec(compact)?.[1]?.toLowerCase() || "";
  let numeric = compact.replace(/(?:tr|[knm])%?$/i, "").replace(/%/g, "").replace(/[^\d.,+-]/g, "");
  if (!numeric || !/\d/.test(numeric)) return null;
  const comma = numeric.lastIndexOf(",");
  const dot = numeric.lastIndexOf(".");
  if (comma >= 0 && dot >= 0) {
    const decimal = Math.max(comma, dot);
    numeric = numeric.slice(0, decimal).replace(/[.,]/g, "") + "." + numeric.slice(decimal + 1).replace(/[.,]/g, "");
  } else if (comma >= 0 || dot >= 0) {
    const separator = comma >= 0 ? "," : ".";
    const pieces = numeric.split(separator);
    if (pieces.length === 2 && pieces[1].length === 3 && pieces[0].length > 0) {
      numeric = pieces.join("");
    } else {
      numeric = pieces.slice(0, -1).join("") + "." + pieces[pieces.length - 1];
    }
  }
  const value = Number(numeric);
  if (!Number.isFinite(value)) return null;
  const multiplier = suffix === "k" || suffix === "n" ? 1_000 : suffix === "m" || suffix === "tr" ? 1_000_000 : 1;
  return value * multiplier;
}

function normalized(value: string): string {
  return value.toLocaleLowerCase("vi").normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim();
}

function valueAfterLabel(lines: string[], aliases: readonly string[]): StatNumber | null {
  const ordered = [...aliases].sort((a, b) => b.length - a.length);
  for (let index = 0; index < lines.length; index += 1) {
    const line = lines[index];
    const lineLower = line.toLocaleLowerCase("vi");
    const alias = ordered.find(candidate => lineLower.includes(candidate.toLocaleLowerCase("vi")));
    if (!alias) continue;
    const position = lineLower.indexOf(alias.toLocaleLowerCase("vi"));
    const inline = line.slice(position + alias.length).trim().replace(/^[:\s-]+/, "");
    for (const candidate of [inline, ...lines.slice(index + 1, index + 3)]) {
      const match = /[-+]?\d[\d.,\s]*(?:%|(?:\s*(?:K|N|M|Tr)))?/i.exec(candidate);
      if (!match) continue;
      const value = parseSo(match[0]);
      if (value !== null) return { value, display: match[0].trim() };
    }
  }
  return null;
}

export function readSummary(text: string): StatsData["summary"] {
  const lines = text.split(/\r?\n/).map(line => line.trim()).filter(Boolean);
  return {
    clicks: valueAfterLabel(lines, SELECTORS.labels.clicks),
    impressions: valueAfterLabel(lines, SELECTORS.labels.impressions),
    ctr: valueAfterLabel(lines, SELECTORS.labels.ctr),
    position: valueAfterLabel(lines, SELECTORS.labels.position)
  };
}

function isPermissionText(text: string): boolean {
  const lower = normalized(text);
  return SELECTORS.permission.some(phrase => lower.includes(normalized(phrase)));
}

function siteVariants(input: string): { site: string; variants: string[] } {
  const raw = input.trim();
  if (!raw) throw new Error("Nhập địa chỉ website hoặc khóa Search Console.");
  let hostname = "";
  try {
    const url = new URL(/^[a-z][a-z\d+.-]*:\/\//i.test(raw) ? raw : `https://${raw}`);
    hostname = url.hostname.toLowerCase().replace(/^www\./, "");
  } catch {
    if (!raw.startsWith("sc-domain:")) throw new Error("Địa chỉ website hoặc khóa Search Console không hợp lệ.");
    hostname = raw.slice("sc-domain:".length).toLowerCase().replace(/^www\./, "");
  }
  const choices = raw.startsWith("sc-domain:")
    ? [raw, `sc-domain:${hostname}`, `https://${hostname}/`, `https://www.${hostname}/`]
    : [`sc-domain:${hostname}`, `https://${hostname}/`, `https://www.${hostname}/`];
  return { site: hostname, variants: [...new Set(choices)] };
}

type PageSnapshot = { url: string; title: string; text: string; aria: string[] };

async function snapshot(page: Page): Promise<PageSnapshot> {
  return page.evaluate(ariaSelector => ({
    url: location.href,
    title: document.title,
    text: document.body?.innerText || "",
    aria: [...document.querySelectorAll(ariaSelector)].map(element =>
      `${element.getAttribute("aria-label") || ""} [${element.tagName.toLowerCase()}]`)
  }), SELECTORS.selectors.aria);
}

async function writeDiagnostic(path: string, page: Page): Promise<boolean> {
  try {
    const details = await snapshot(page);
    const content = truncateUtf8([
      `URL\n${details.url}`,
      `document.title\n${details.title}`,
      `innerText\n${details.text}`,
      `Phần tử có aria-label\n${details.aria.join("\n")}`
    ].join("\n\n"), MAX_DUMP_BYTES);
    await mkdir(resolve("data"), { recursive: true });
    await writeFile(resolve("data", path), content, "utf8");
    return true;
  } catch {
    return false;
  }
}

async function waitForNumbers(page: Page, timeout: number): Promise<void> {
  await page.waitForFunction(labels => {
    const text = document.body?.innerText?.toLocaleLowerCase() || "";
    return labels.every(group => group.some(label => text.includes(label)));
  }, { timeout, polling: 300 }, Object.values(SELECTORS.labels));
}

function periodFrom(text: string): string {
  return /\d+\s*(?:ngày|tháng|days?|months?)/i.exec(text)?.[0] || "Khoảng thời gian đang chọn trên trang Google";
}

async function clickTab(page: Page, aliases: readonly string[]): Promise<boolean> {
  return page.evaluate((selector, names) => {
    const normalizeText = (value: string) => value.toLocaleLowerCase().trim().replace(/\s+/g, " ");
    const candidates = [...document.querySelectorAll(selector)].map(element => ({
      element,
      text: normalizeText((element as HTMLElement).innerText || element.textContent || "")
    })).filter(item => item.text && names.some(name => item.text === name || item.text.includes(name)));
    candidates.sort((a, b) => a.text.length - b.text.length);
    const target = candidates[0]?.element as HTMLElement | undefined;
    if (!target) return false;
    target.click();
    return true;
  }, SELECTORS.selectors.tab, [...aliases]);
}

async function readRows(page: Page): Promise<MetricRow[]> {
  const rows = await page.evaluate((rowSelector, cellSelector) =>
    [...document.querySelectorAll(rowSelector)]
      .map(row => [...row.querySelectorAll(cellSelector)].map(cell => (cell as HTMLElement).innerText.trim()))
      .filter(cells => cells.length >= 2), SELECTORS.selectors.row, SELECTORS.selectors.cell);
  if (!rows.length) return [];
  const headers = rows[0].map(normalized);
  const indexes = Object.values(SELECTORS.columns).map(names =>
    headers.findIndex(header => names.some(name => header.includes(normalized(name)))));
  const columns = indexes.every(index => index >= 0) ? indexes : [1, 2, 3, 4];
  return rows.slice(1).filter(cells => cells[0]).map(cells => ({
    key: cells[0],
    clicks: parseSo(cells[columns[0]] || ""),
    impressions: parseSo(cells[columns[1]] || ""),
    ctr: parseSo(cells[columns[2]] || ""),
    position: parseSo(cells[columns[3]] || "")
  }));
}

async function readTab(page: Page, aliases: readonly string[]): Promise<MetricRow[]> {
  if (!(await clickTab(page, aliases))) throw new Error("Không tìm thấy mục dữ liệu trên trang.");
  await new Promise(resolveDelay => setTimeout(resolveDelay, 2000));
  const rows = await readRows(page);
  if (!rows.length) throw new Error("Trang không có bảng dữ liệu đọc được.");
  return rows;
}

async function analyticsData(browser: Browser): Promise<{ rows: Array<{ label: string; value: string }>; diagnostic: boolean }> {
  const pages = await browser.pages();
  let page = pages.find(candidate => {
    try { return new URL(candidate.url()).hostname === "analytics.google.com"; } catch { return false; }
  });
  let owned = false;
  if (!page) {
    page = await browser.newPage();
    owned = true;
  }
  try {
    if (!page.url().includes("analytics.google.com")) {
      await page.goto("https://analytics.google.com", { waitUntil: "domcontentloaded", timeout: 15_000 });
    }
    if (await loginRequired(browser)) {
      return { rows: [], diagnostic: await writeDiagnostic("dump-ga.txt", page) };
    }
    const text = await page.evaluate(() => document.body?.innerText || "");
    const lines = text.split(/\r?\n/).map(line => line.trim()).filter(Boolean);
    const results: Array<{ label: string; value: string }> = [];
    for (let i = 0; i < lines.length - 1; i += 1) {
      const label = lines[i];
      const value = lines[i + 1];
      if (label.length > 80 || label.length < 2 || parseSo(value) === null) continue;
      if (!/\d/.test(value) || results.some(item => item.label === label)) continue;
      results.push({ label, value });
    }
    return { rows: results, diagnostic: !results.length && await writeDiagnostic("dump-ga.txt", page) };
  } catch {
    return { rows: [], diagnostic: Boolean(page && await writeDiagnostic("dump-ga.txt", page)) };
  } finally {
    if (owned) await page.close().catch(() => undefined);
  }
}

async function connectExisting(): Promise<Browser> {
  if (!(await debugVersion())) throw new Error("Chưa mở Chrome bằng nút Kết nối.");
  try { return await puppeteer.connect({ browserURL: DEBUG_URL }); } catch {
    throw new Error("Không kết nối được với Chrome. Bấm Kết nối rồi mở lại mục thống kê.");
  }
}

export async function readGoogleStats(input: string, typedKey?: string): Promise<StatsData> {
  const startedAt = Date.now();
  const browser = await connectExisting();
  try {
    const { site, variants } = siteVariants(input);
    if (await loginRequired(browser)) throw new Error(LOGIN_MESSAGE);
    await ensureSearchConsolePage(browser);
    const page = (await googlePages(browser, "search.google.com"))[0];
    if (!page) throw new Error("Không tìm thấy tab Search Console trong Chrome.");
    const candidates = typedKey?.trim() ? [typedKey.trim(), ...variants] : variants;
    let selectedKey = candidates[0];
    let snapshotData: PageSnapshot = { url: page.url(), title: "", text: "", aria: [] };
    let summary = readSummary("");
    let metricCount = 0;
    let denied = false;
    for (const key of [...new Set(candidates)]) {
      selectedKey = key;
      const remaining = 15_000 - (Date.now() - startedAt);
      if (remaining <= 0) break;
      try {
        await page.goto(`https://search.google.com/search-console/performance/search-analytics?resource_id=${encodeURIComponent(key)}`, {
          waitUntil: "domcontentloaded",
          timeout: Math.min(remaining, 5000)
        });
        const permissionText = (await page.evaluate(() => document.body?.innerText || "")).slice(0, 5000);
        if (isPermissionText(permissionText)) { denied = true; continue; }
        const afterNavigation = 15_000 - (Date.now() - startedAt);
        if (afterNavigation > 0) await waitForNumbers(page, afterNavigation);
      } catch {
        if (Date.now() - startedAt >= 15_000) break;
      }
      snapshotData = await snapshot(page);
      if (isPermissionText(snapshotData.text)) { denied = true; continue; }
      const currentSummary = readSummary(snapshotData.text);
      const currentCount = Object.values(currentSummary).filter(Boolean).length;
      if (currentCount > metricCount) {
        summary = currentSummary;
        snapshotData = await snapshot(page);
        metricCount = currentCount;
      }
      if (metricCount === 4) break;
    }
    if (denied && metricCount === 0) {
      throw new Error(`Tài khoản Google chưa có quyền truy cập dữ liệu của ${site}.`);
    }
    const hasSummary = metricCount === 4;
    const messages: string[] = [];
    let diagnostic: string | undefined;
    if (!hasSummary) {
      diagnostic = await writeDiagnostic("dump-gsc.txt", page)
        ? "Chưa đọc được số liệu Search Console. Đã lưu thông tin chẩn đoán vào data/dump-gsc.txt."
        : "Chưa đọc được số liệu Search Console. Không lưu được tệp chẩn đoán.";
    }
    const groupResults: Record<string, MetricRow[]> = {};
    const tabNames: Record<string, string> = {
      queries: "Truy vấn",
      pages: "Trang",
      devices: "Thiết bị",
      countries: "Quốc gia",
      searchAppearance: "Giao diện tìm kiếm"
    };
    for (const [key, aliases] of Object.entries(SELECTORS.tabs)) {
      try { groupResults[key] = await readTab(page, aliases); }
      catch { messages.push(`Không đọc được bảng ${tabNames[key]} trong Search Console.`); }
    }
    let ga: Array<{ label: string; value: string }> = [];
    let gaDiagnostic = "";
    try {
      const analytics = await analyticsData(browser);
      ga = analytics.rows;
      if (!ga.length) gaDiagnostic = analytics.diagnostic
        ? "Chưa đọc được Google Analytics. Đã lưu thông tin chẩn đoán vào data/dump-ga.txt."
        : "Chưa đọc được Google Analytics. Không lưu được tệp chẩn đoán.";
      if (!ga.length) messages.push("Chưa đọc được Google Analytics");
    } catch {
      messages.push("Chưa đọc được Google Analytics");
    }
    if (hasSummary && !Object.values(groupResults).some(rows => rows.length)) {
      messages.push("Không đọc được các bảng Search Console; các thẻ tổng quan vẫn hiển thị.");
    }
    if (!hasSummary) messages.push("Website này chưa có số liệu trong khoảng thời gian đang chọn");
    return {
      connected: true,
      site,
      selectedKey,
      green: hasSummary,
      period: periodFrom(snapshotData.text),
      summary,
      queries: groupResults.queries || [],
      pages: groupResults.pages || [],
      devices: groupResults.devices || [],
      countries: groupResults.countries || [],
      searchAppearance: groupResults.searchAppearance || [],
      ga,
      gaDiagnostic,
      messages,
      diagnostic
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : "";
    if (message === LOGIN_MESSAGE || message.startsWith("Tài khoản Google chưa có quyền")) throw error;
    throw new Error(message.startsWith("Chưa mở Chrome") || message.startsWith("Không kết nối được với Chrome")
      ? message : "Không đọc được Search Console. Trạng thái đăng nhập Google hoặc website đã chọn chưa phù hợp.");
  } finally {
    browser.disconnect();
  }
}

export async function logoutGoogle(): Promise<{ message: string }> {
  const browser = await connectExisting();
  let closed = false;
  try {
    const context = browser.defaultBrowserContext();
    const cookies = await context.cookies();
    const googleCookies = cookies.filter(cookie => cookie.domain.toLowerCase().includes("google."));
    if (googleCookies.length) await context.deleteCookie(...googleCookies);
    await browser.close();
    closed = true;
    for (let attempt = 0; attempt < 20 && await debugVersion(); attempt += 1) {
      await new Promise(resolveDelay => setTimeout(resolveDelay, 250));
    }
    const executable = await findChrome();
    await new Promise<void>((resolveSpawn, rejectSpawn) => {
      const child = spawn(executable, [
        "--remote-debugging-port=9222",
        `--user-data-dir=${PROFILE}`,
        "https://accounts.google.com/"
      ], { detached: true, stdio: "ignore", windowsHide: false });
      child.once("error", rejectSpawn);
      child.once("spawn", () => { child.unref(); resolveSpawn(); });
    });
    for (let attempt = 0; attempt < 30; attempt += 1) {
      if (await debugVersion()) return { message: "Đã đổi tài khoản Google. Chrome đã mở lại để đăng nhập tài khoản khác." };
      await new Promise(resolveDelay => setTimeout(resolveDelay, 500));
    }
    throw new Error("Chrome chưa mở lại được sau khi đổi tài khoản.");
  } catch {
    throw new Error("Không đổi được tài khoản Google. Kiểm tra Chrome đang mở.");
  } finally {
    if (!closed) browser.disconnect();
  }
}
