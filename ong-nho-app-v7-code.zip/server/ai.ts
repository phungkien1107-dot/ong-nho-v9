import OpenAI from "openai";

const TEXT_MODEL = "gpt-6-luna";
const IMAGE_MODEL = "gpt-6.1-terra";
const AI_ERROR = "Chưa kết nối được AI, kiểm tra OPENAI_API_KEY trong file .env";
const FORBIDDEN = ["nên", "hãy", "cần", "gợi ý", "đề xuất", "khuyên", "thử", "lộ trình", "tư vấn", "việc cần làm"];
const TIMEOUT_MS = 60_000;

type Criterion = {
  id?: number;
  ten?: string;
  name?: string;
  diemDat?: number;
  diemToiDa?: number;
  trangThai?: string;
  tinhTrang?: string;
  yNghia?: string;
  meaning?: string;
};
type AuditInput = { score?: number; findings?: Criterion[] };
export type Review = {
  diemManh: string[];
  diemYeu: string[];
  tieuChiLienQuan: { diemManh: number[][]; diemYeu: number[][] };
};
type SpellingError = { tuSai: string; cauChuaTu: string };
type CompareSite = {
  ten: string;
  score: number;
  groupScores: Array<{ nhom: string; diem: number; diemToiDa: number }>;
  findings: Array<Criterion & { nhom: string; diemDat: number; diemToiDa: number }>;
};
type CompareReview = { ketLuan: string[]; loiAI: string };
type StatsMetric = { value: number; display: string } | null;
type StatsInsightInput = {
  period: string;
  summary: { clicks: StatsMetric; impressions: StatsMetric; ctr: StatsMetric; position: StatsMetric };
  devices: Array<{ key: string; clicks: number | null; impressions: number | null; ctr: number | null; position: number | null }>;
};
let client: OpenAI | undefined;

function aiError(error: unknown): Error {
  console.error("[AI]", error);
  const message = error instanceof Error
    ? error.message
    : typeof error === "object" && error !== null && "message" in error && typeof error.message === "string"
      ? error.message
      : String(error);
  if (message === AI_ERROR) return error instanceof Error ? error : new Error(AI_ERROR);
  const status = typeof error === "object" && error !== null && "status" in error
    ? error.status
    : undefined;
  if (status === 401) return new Error("OPENAI_API_KEY sai hoặc bị thu hồi.");
  if (status === 404) return new Error("Tài khoản không có model này, kiểm tra TEXT_MODEL/IMAGE_MODEL đầu file ai.ts.");
  if (status === 429) return new Error("Hết hạn mức hoặc gọi quá nhanh (429).");
  return new Error(`Lỗi AI: ${message.slice(0, 120)}`);
}

export function locTuCam(chuoi: string): boolean {
  const normalized = ` ${chuoi.toLocaleLowerCase("vi").replace(/[^\p{L}\p{N}]+/gu, " ").trim()} `;
  return FORBIDDEN.some(word => normalized.includes(` ${word} `));
}

function getClient(): OpenAI {
  if (!process.env.OPENAI_API_KEY) throw new Error(AI_ERROR);
  return client ??= new OpenAI({ apiKey: process.env.OPENAI_API_KEY, timeout: TIMEOUT_MS, maxRetries: 0 });
}

function parseJson<T>(value: string): T {
  const parsed = JSON.parse(value) as T;
  if (!parsed || typeof parsed !== "object") throw new Error("AI trả kết quả không đúng định dạng.");
  return parsed;
}

function numbers(value: string): string[] {
  return value.match(/\d+(?:[.,]\d+)*%?/g) || [];
}

function hasOnlySourceNumbers(value: string, source: string): boolean {
  const allowed = new Set(numbers(source));
  return numbers(value).every(number => allowed.has(number));
}

function safeSentences(values: string[], source: string): string[] {
  return values.filter(value => typeof value === "string" && value.trim() &&
    !locTuCam(value) && hasOnlySourceNumbers(value, source)).map(value => value.trim());
}

function reviewFallback(findings: Criterion[], strong: boolean): { lines: string[]; ids: number[][] } {
  const ranked = findings.filter(item => item.id !== undefined && item.diemDat !== undefined &&
    item.diemToiDa !== undefined && item.trangThai !== "khong_ap_dung")
    .sort((a, b) => {
      const ratioA = a.diemDat! / Math.max(1, a.diemToiDa!);
      const ratioB = b.diemDat! / Math.max(1, b.diemToiDa!);
      return strong ? ratioB - ratioA : ratioA - ratioB;
    }).slice(0, 3);
  return {
    lines: ranked.map(item => item.tinhTrang || ""),
    ids: ranked.map(item => [item.id!])
  };
}

export function fallbackNhanXet(input: AuditInput): Review {
  const findings = Array.isArray(input.findings) ? input.findings : [];
  const strong = reviewFallback(findings, true);
  const weak = reviewFallback(findings, false);
  return { diemManh: strong.lines, diemYeu: weak.lines, tieuChiLienQuan: { diemManh: strong.ids, diemYeu: weak.ids } };
}

export async function nhanXet(ketQuaChamDiem: AuditInput): Promise<Review> {
  const findings = Array.isArray(ketQuaChamDiem.findings) ? ketQuaChamDiem.findings : [];
  const data = {
    diemTong: ketQuaChamDiem.score,
    tieuChi: findings.map(item => ({
      id: item.id,
      ten: item.ten || item.name,
      diemDat: item.diemDat,
      diemToiDa: item.diemToiDa,
      trangThai: item.trangThai,
      tinhTrang: item.tinhTrang,
      yNghia: item.yNghia || item.meaning
    }))
  };
  const source = JSON.stringify(data);
  const fallback = fallbackNhanXet(ketQuaChamDiem);
  const allowedIds = new Set(findings.flatMap(item => item.id === undefined ? [] : [item.id]));
  const checked = (lines: string[], ids: number[][] | undefined, strong: boolean) => {
    const validLines = (lines || []).map((line, index) => ({ line, index }))
      .filter(item => safeSentences([item.line], source).length === 1);
    if (validLines.length !== 3) return null;
    return {
      lines: validLines.map(item => item.line.trim()),
      ids: validLines.map((item, index) => {
        const linked = (ids?.[item.index] || []).filter(id => Number.isInteger(id) && allowedIds.has(id)).slice(0, 2);
        return linked.length ? linked : fallback.tieuChiLienQuan[strong ? "diemManh" : "diemYeu"][index] || [];
      })
    };
  };
  try {
    const request = async (retry: boolean): Promise<Review> => {
      const response = await getClient().responses.create({
        model: TEXT_MODEL,
        instructions: `Viết tiếng Việt như báo cáo chuyên nghiệp, phù hợp với mọi loại website. Chỉ mô tả tình hình và ý nghĩa, không khuyến nghị. Chỉ dùng dữ kiện có trong dữ liệu. Trả JSON đúng dạng {"diemManh":["...","...","..."],"diemYeu":["...","...","..."],"tieuChiLienQuan":{"diemManh":[[1],[2],[3]],"diemYeu":[[4],[5],[6]]}}. Mỗi danh sách phải có đúng 3 câu ngắn; mỗi mục liên quan 1 hoặc 2 ID có trong dữ liệu. Không dùng từ nên, hãy, cần, gợi ý, đề xuất, khuyên, thử.`,
        input: JSON.stringify({ duLieu: data, yeuCauTaoLai: retry ? "Kết quả trước chưa đủ 3 câu hợp lệ cho mỗi danh sách. Trả đủ đúng 3 câu mỗi danh sách." : undefined }),
        text: { format: { type: "json_object" } }
      });
      const result = parseJson<Review>(response.output_text);
      const diemManh = checked(result.diemManh, result.tieuChiLienQuan?.diemManh, true);
      const diemYeu = checked(result.diemYeu, result.tieuChiLienQuan?.diemYeu, false);
      if (diemManh && diemYeu) return {
        diemManh: diemManh.lines,
        diemYeu: diemYeu.lines,
        tieuChiLienQuan: { diemManh: diemManh.ids, diemYeu: diemYeu.ids }
      };
      if (!retry) return request(true);
      return {
        diemManh: diemManh?.lines || fallback.diemManh,
        diemYeu: diemYeu?.lines || fallback.diemYeu,
        tieuChiLienQuan: {
          diemManh: diemManh?.ids || fallback.tieuChiLienQuan.diemManh,
          diemYeu: diemYeu?.ids || fallback.tieuChiLienQuan.diemYeu
        }
      };
    };
    return await request(false);
  } catch (error) {
    throw aiError(error);
  }
}

function visibleText(input: string): string {
  return input
    .replace(/<!--[\s\S]*?-->/g, " ")
    .replace(/<(script|style|noscript|template)\b[^>]*>[\s\S]*?<\/\1\s*>/gi, " ")
    .replace(/<([a-z][\w:-]*)\b(?=[^>]*(?:hidden\b|aria-hidden=["']true["']|display\s*:\s*none|visibility\s*:\s*hidden))[^>]*>[\s\S]*?<\/\1\s*>/gi, " ")
    .replace(/<[^>]*>/g, " ")
    .replace(/&nbsp;|&#160;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 3000);
}

function pageLanguage(html: string): string {
  return /<html\b[^>]*\blang=["']([^"']+)/i.exec(html)?.[1] || "tự nhận dạng từ văn bản";
}

export async function chinhTa(vanBanTrang: string): Promise<SpellingError[]> {
  const text = visibleText(vanBanTrang);
  if (!text) return [];
  const source = JSON.stringify({ ngonNgu: pageLanguage(vanBanTrang), vanBan: text });
  try {
    const request = async (retry: boolean): Promise<SpellingError[]> => {
      const response = await getClient().responses.create({
        model: TEXT_MODEL,
        instructions: `Kiểm tra lỗi chính tả theo đúng ngôn ngữ ${pageLanguage(vanBanTrang)}. Chỉ đánh dấu lỗi chính tả chắc chắn trong văn bản, giữ nguyên chữ hoa chữ thường của đoạn trích. Trả JSON {"loi":[{"tuSai":"từ sai","cauChuaTu":"câu chứa từ"}]}. Không thêm lời khuyên, không tự sửa văn phong. Mỗi câu trích phải nằm nguyên văn trong văn bản đầu vào.${retry ? " Kết quả trước không hợp lệ, hãy trả lại JSON chỉ chứa lỗi chắc chắn và câu trích nguyên văn." : ""}`,
        input: source,
        text: { format: { type: "json_object" } }
      });
      const parsed = parseJson<{ loi?: SpellingError[] }>(response.output_text);
      const issues = (parsed.loi || []).filter(issue =>
        typeof issue.tuSai === "string" &&
        typeof issue.cauChuaTu === "string" &&
        issue.cauChuaTu.includes(issue.tuSai) &&
        text.includes(issue.cauChuaTu) &&
        !locTuCam(issue.tuSai) &&
        !locTuCam(issue.cauChuaTu) &&
        hasOnlySourceNumbers(`${issue.tuSai} ${issue.cauChuaTu}`, source)
      );
      if (issues.length === (parsed.loi || []).length) return issues;
      if (!retry) return request(true);
      return issues;
    };
    return await request(false);
  } catch (error) {
    throw aiError(error);
  }
}

export async function docAnh(anhBase64: string): Promise<string> {
  if (!anhBase64) return "";
  try {
    const dataUrl = anhBase64.startsWith("data:image/") ? anhBase64 : `data:image/jpeg;base64,${anhBase64}`;
    const response = await getClient().responses.create({
      model: IMAGE_MODEL,
      instructions: "Trả JSON bằng tiếng Việt chuyên nghiệp, 2 hoặc 3 câu, mô tả ấn tượng thị giác và tình hình bố cục nhìn thấy khi mở trang. Chỉ nêu tình hình, không khuyến nghị, không thêm số liệu.",
      input: [{
        role: "user",
        content: [
          { type: "input_text", text: "Mô tả ấn tượng nhìn thấy trong ảnh website." },
          { type: "input_image", image_url: dataUrl, detail: "auto" }
        ]
      }],
      text: { format: { type: "json_object" } }
    });
    const result = parseJson<{ moTa?: string; mo_ta?: string }>(response.output_text);
    const description = result.moTa || result.mo_ta || "";
    return !locTuCam(description) && !numbers(description).length ? description : "";
  } catch {
    return "";
  }
}

export async function summarizeAudit(data: { url?: string; score?: number; findings?: Criterion[] }): Promise<string> {
  const review = await nhanXet(data);
  return [...review.diemManh, ...review.diemYeu].join("\n");
}

export async function describeImage(imageData: string): Promise<string> {
  return docAnh(imageData);
}

function fallbackComparison(sites: CompareSite[]): string[] {
  const groups = ["Nội dung", "Kỹ thuật & tìm kiếm", "Di động & tốc độ", "Mạng xã hội", "Giao diện & trải nghiệm"];
  const customer = sites[0];
  if (!customer || sites.length < 2) return [];
  return groups.map(group => {
    const customerScore = customer.groupScores.find(item => item.nhom === group) || { diem: 0, diemToiDa: 0 };
    const rival = sites.slice(1).map(site => ({
      site,
      score: site.groupScores.find(item => item.nhom === group) || { diem: 0, diemToiDa: 0 }
    })).reduce((best, item) => item.score.diem > best.score.diem ? item : best);
    const outcome = customerScore.diem > rival.score.diem ? "hơn" : customerScore.diem < rival.score.diem ? "thua" : "bằng";
    return `${group}: ${customer.ten} ${customerScore.diem}/${customerScore.diemToiDa} điểm, ${rival.site.ten} ${rival.score.diem}/${rival.score.diemToiDa} điểm, khách ${outcome} đối thủ.`;
  });
}

export async function ketLuanSoSanh(sites: CompareSite[]): Promise<CompareReview> {
  const data = sites.map(site => ({
    ten: site.ten,
    diemTong: site.score,
    nhom: site.groupScores,
    tieuChi: site.findings.map(item => ({
      id: item.id,
      nhom: item.nhom,
      ten: item.ten || item.name,
      diemDat: item.diemDat,
      diemToiDa: item.diemToiDa,
      tinhTrang: item.tinhTrang,
      yNghia: item.yNghia || item.meaning
    }))
  }));
  const source = JSON.stringify(data);
  const fallback = fallbackComparison(sites);
  if (!fallback.length) return { ketLuan: [], loiAI: "" };
  try {
    const request = async (retry: boolean): Promise<CompareReview> => {
      const response = await getClient().responses.create({
        model: TEXT_MODEL,
        instructions: `Viết đúng 5 ý, mỗi nhóm một ý, mỗi ý dưới 30 từ bằng tiếng Việt như báo cáo chuyên nghiệp. Bao quát đủ cả 5 nhóm: Nội dung, Kỹ thuật & tìm kiếm, Di động & tốc độ, Mạng xã hội, Giao diện & trải nghiệm. Mỗi ý nêu tình hình và ý nghĩa dựa trên số điểm thật giữa các website; mọi ý có số liệu điểm và tên nhóm. Không đưa lời khuyên, kế hoạch, lộ trình hoặc việc cần làm. Chỉ dùng số có trong dữ liệu. Trả JSON {"ketLuan":["..."]}. Không dùng các từ nên, hãy, cần, gợi ý, đề xuất, khuyên, thử.${retry ? " Lần trước chưa đủ 5 ý hợp lệ hoặc thiếu nhóm; trả lại đúng 5 ý hợp lệ, mỗi ý dưới 30 từ." : ""}`,
        input: JSON.stringify({ websites: data }),
        text: { format: { type: "json_object" } }
      });
      const parsed = parseJson<{ ketLuan?: string[] }>(response.output_text);
      const statements = safeSentences(parsed.ketLuan || [], source)
        .filter(line => numbers(line).length > 0 && ["Nội dung", "Kỹ thuật & tìm kiếm", "Di động & tốc độ", "Mạng xã hội", "Giao diện & trải nghiệm"].some(group => line.includes(group)));
      const allGroups = ["Nội dung", "Kỹ thuật & tìm kiếm", "Di động & tốc độ", "Mạng xã hội", "Giao diện & trải nghiệm"]
        .every(group => statements.some(line => line.includes(group)));
      if (statements.length === 5 && allGroups) return { ketLuan: statements, loiAI: "" };
      if (!retry) return request(true);
      return { ketLuan: fallback, loiAI: "" };
    };
    return await request(false);
  } catch (error) {
    return { ketLuan: fallback, loiAI: aiError(error).message };
  }
}

function statsFallback(data: StatsInsightInput, kind: "overview" | "devices"): string[] {
  if (kind === "overview") {
    const { clicks, impressions, ctr, position } = data.summary;
    if (!clicks || !impressions || !ctr || !position) return [];
    return [
      `Trong khoảng ${data.period}, trang ghi nhận ${clicks.display} lượt nhấp.`,
      `Trang có ${impressions.display} lượt hiển thị và CTR ${ctr.display}.`,
      `Vị trí trung bình ghi nhận ${position.display}.`
    ];
  }
  const rows = data.devices.filter(row =>
    row.clicks !== null && row.impressions !== null && row.ctr !== null && row.position !== null);
  if (!rows.length) return [];
  const describe = (row: typeof rows[number]) =>
    `${row.key}: ${row.clicks} lượt nhấp, ${row.impressions} lượt hiển thị, CTR ${row.ctr}%, vị trí ${row.position}`;
  if (rows.length === 1) return [
    `Thống kê thiết bị ghi nhận ${describe(rows[0])}.`,
    `CTR ${rows[0].ctr}% và vị trí ${rows[0].position} mô tả mức hiển thị của ${rows[0].key}.`
  ];
  return [
    `Thống kê thiết bị ghi nhận ${describe(rows[0])}.`,
    `${describe(rows[1])}.`,
    rows.length > 2 ? `${describe(rows[2])}.` : "Hai loại thiết bị có các chỉ số riêng."
  ];
}

export async function nhanDinhThongKe(
  data: StatsInsightInput,
  kind: "overview" | "devices" = "overview"
): Promise<string[]> {
  const source = JSON.stringify(data);
  const fallback = statsFallback(data, kind);
  if (!fallback.length) return [];
  const minimum = kind === "overview" ? 3 : 2;
  const maximum = kind === "overview" ? 5 : 3;
  try {
    const request = async (retry: boolean): Promise<string[]> => {
      const response = await getClient().responses.create({
        model: TEXT_MODEL,
        instructions: `Viết ${minimum} đến ${maximum} câu tiếng Việt chuyên nghiệp, chỉ mô tả tình hình và ý nghĩa của số liệu thật trong dữ liệu. Không khuyến nghị. Mọi con số phải xuất hiện nguyên dạng trong dữ liệu đầu vào. Trả JSON {"nhanDinh":["..."]}. Không dùng các từ nên, hãy, cần, gợi ý, đề xuất, khuyên, thử.${retry ? " Kết quả trước chưa đủ câu hợp lệ; trả lại đủ số câu với số liệu nguyên dạng." : ""}`,
        input: JSON.stringify({ loai: kind, duLieu: data }),
        text: { format: { type: "json_object" } }
      });
      const result = parseJson<{ nhanDinh?: string[] }>(response.output_text);
      const sentences = safeSentences(result.nhanDinh || [], source);
      if (sentences.length >= minimum && sentences.length <= maximum) return sentences;
      if (!retry) return request(true);
      return fallback;
    };
    return await request(false);
  } catch {
    return fallback;
  }
}
