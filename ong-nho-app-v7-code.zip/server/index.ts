import "dotenv/config";
import express from "express";
import { existsSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { resolve } from "node:path";
import { createServer as createViteServer } from "vite";
import { fetchPage } from "./fetchPage.js";
import { scorePage } from "./score.js";
import { nhanXet, fallbackNhanXet, chinhTa, docAnh, summarizeAudit, describeImage, ketLuanSoSanh, nhanDinhThongKe } from "./ai.js";
import { createPdf, createShot, chupTrang, chupPhanTu, type Rect } from "./shot.js";
import { connectStats, dumpGooglePages, logoutGoogle, readGoogleStats } from "./stats.js";

const root = resolve(fileURLToPath(new URL("..", import.meta.url)));
const app = express();
app.use(express.json({ limit: "25mb" }));

app.get("/api/health", (_req, res) => res.json({ ok: true }));
app.post("/api/check", async (req, res) => {
  try {
    const url = String(req.body?.url || "");
    const pagePromise = fetchPage(url);
    const auditPromise = pagePromise.then(scorePage);
    const extraIdsPromise = auditPromise.then(audit => audit.findings
      .filter(item => item.trangThai !== "khong_ap_dung" && [3, 4, 5, 6, 21, 22, 23, 25].includes(item.id))
      .map(item => item.id));
    extraIdsPromise.catch(() => {});
    const shotPromise = chupTrang(url, extraIdsPromise, 60);
    const [page, audit, shot] = await Promise.all([pagePromise, auditPromise, shotPromise]);
    const [reviewResult, imageResult] = await Promise.allSettled([
      nhanXet(audit),
      docAnh(shot.anh || "")
    ]);
    const rejectedAI = [reviewResult, imageResult].find(result => result.status === "rejected");
    const loiAI = rejectedAI
      ? rejectedAI.reason instanceof Error ? rejectedAI.reason.message : "Lỗi AI không rõ"
      : "";
    const rectForId: Record<number, Rect["id"]> = {
      3: "h1",
      5: "anh_alt",
      21: "cta",
      25: "dieu_huong"
    };
    const findings = audit.findings.map(item => {
      const rectId = rectForId[item.id];
      const matches = rectId ? shot.rects.filter(rect => rect.id === rectId) : [];
      return matches.length ? { ...item, rect: matches.length === 1 ? matches[0] : matches } : item;
    });
    const ghiChu = findings
      .filter(item => !("rect" in item))
      .map(item => ({ id: item.id, ten: item.ten, tinhTrang: item.tinhTrang }));
    res.json({
      page: {
        ...page,
        compressedBytes: null,
        compression: page.contentEncoding || "không ghi nhận"
      },
      anh: shot.anh,
      rects: shot.rects,
      anhPhu: shot.anhPhu,
      loiChup: shot.loi,
      nhanXet: reviewResult.status === "fulfilled" ? reviewResult.value : fallbackNhanXet(audit),
      loiChinhTa: [],
      docAnh: imageResult.status === "fulfilled" ? imageResult.value : "",
      loiAI,
      ghiChu,
      ...audit,
      findings
    });
  } catch (error) { sendError(res, error); }
});
app.post("/api/spelling", async (req, res) => {
  try {
    const page = await fetchPage(String(req.body?.url || ""));
    const issues = await chinhTa(page.html);
    const details = issues.length ? await chupPhanTu(page.finalUrl, [], issues) : { anhChinhTa: [] };
    res.json({ issues, images: details.anhChinhTa });
  } catch (error) { sendError(res, error); }
});
app.post("/api/compare", async (req, res) => {
  try {
    const customerUrl = String(req.body?.urlKhach || "").trim();
    const competitors = Array.isArray(req.body?.urlDoiThu)
      ? req.body.urlDoiThu.map((url: unknown) => String(url || "").trim()).filter(Boolean)
      : [];
    if (!customerUrl || competitors.length < 1 || competitors.length > 3) {
      throw new Error("Nhập địa chỉ website khách và từ 1 đến 3 website đối thủ.");
    }
    const urls = [customerUrl, ...competitors];
    const domains = urls.map(compareDomain);
    if (new Set(domains).size !== domains.length) throw new Error("Có địa chỉ trùng tên miền trong danh sách so sánh.");

    const sites: Array<{ url: string; domain: string; audit?: Record<string, unknown>; error?: string }> = [];
    for (let index = 0; index < urls.length; index += 1) {
      const url = urls[index];
      try {
        const page = await fetchPage(url);
        if (page.status < 200 || page.status >= 300) throw new Error(`Website phản hồi mã ${page.status}, không tải được nội dung thành công.`);
        const audit = scorePage(page);
        let shot: Awaited<ReturnType<typeof chupTrang>> = { anh: null, rects: [], anhPhu: [], anhChinhTa: [] };
        try {
          const extraIds = audit.findings
            .filter(item => item.trangThai !== "khong_ap_dung" && [3, 4, 5, 6, 21, 22, 23, 25].includes(item.id))
            .map(item => item.id);
          shot = await chupTrang(page.finalUrl, Promise.resolve(extraIds), 60);
        } catch { /* Điểm vẫn có thể hiển thị nếu ảnh không chụp được. */ }
        const rectForId: Record<number, Rect["id"]> = { 3: "h1", 5: "anh_alt", 21: "cta", 25: "dieu_huong" };
        const findings = audit.findings.map(item => {
          const rectId = rectForId[item.id];
          const matches = rectId ? shot.rects.filter(rect => rect.id === rectId) : [];
          return matches.length ? { ...item, rect: matches.length === 1 ? matches[0] : matches } : item;
        });
        const ghiChu = findings
          .filter(item => !("rect" in item))
          .map(item => ({ id: item.id, ten: item.ten, tinhTrang: item.tinhTrang }));
        sites.push({
          url,
          domain: compareDomain(page.finalUrl),
          audit: {
            ...audit,
            findings,
            page: { ...page, compressedBytes: null, compression: page.contentEncoding || "không ghi nhận", html: "" },
            anh: shot.anh,
            rects: shot.rects,
            anhPhu: shot.anhPhu,
            loiChup: shot.loi || "",
            nhanXet: { diemManh: [], diemYeu: [] },
            loiChinhTa: [],
            docAnh: "",
            loiAI: "",
            ghiChu
          }
        });
      } catch (error) {
        sites.push({
          url,
          domain: domains[index],
          error: compareError(error)
        });
      }
    }
    const available = sites.filter((site): site is typeof site & { audit: Record<string, unknown> } => Boolean(site.audit));
    let ketLuan: string[] = [];
    let loiAI = "";
    if (available.length > 1) {
      const review = await ketLuanSoSanh(available.map(site => ({
        ten: site.domain,
        score: Number(site.audit.score),
        groupScores: site.audit.groupScores as Array<{ nhom: string; diem: number; diemToiDa: number }>,
        findings: site.audit.findings as Array<{
          id: number; nhom: string; ten: string; name: string; diemDat: number; diemToiDa: number;
          tinhTrang: string; yNghia: string; meaning: string;
        }>
      })));
      ketLuan = review.ketLuan;
      loiAI = review.loiAI;
    }
    res.json({ sites, ketLuan, loiAI });
  } catch (error) { sendError(res, error); }
});
app.post("/api/ai", async (req, res) => {
  try { res.json({ summary: await summarizeAudit(req.body) }); } catch (error) { sendError(res, error); }
});
app.post("/api/ai/image", async (req, res) => {
  try {
    const image = String(req.body?.image || "");
    if (!/^data:image\/(png|jpeg|webp);base64,/.test(image) || image.length > 4_000_000) throw new Error("Ảnh không hợp lệ hoặc vượt quá 3 MB.");
    res.json({ summary: await describeImage(image) });
  } catch (error) { sendError(res, error); }
});
app.post("/api/shot", async (req, res) => {
  try { res.json(await createShot(String(req.body?.url || ""))); } catch (error) { sendError(res, error); }
});
app.post("/api/pdf", async (req, res) => {
  try {
    const pdf = await createPdf(req.body);
    res.type("application/pdf");
    res.setHeader("Content-Disposition", 'attachment; filename="ong-nho-bao-cao.pdf"');
    res.send(Buffer.from(pdf));
  } catch (error) { sendError(res, error); }
});
app.post("/api/stats/connect", async (_req, res) => {
  try { res.json(await connectStats()); } catch (error) { sendError(res, error); }
});
app.post("/api/stats/dump", async (_req, res) => {
  try { res.json(await dumpGooglePages()); } catch (error) { sendError(res, error); }
});
app.post("/api/stats/data", async (req, res) => {
  try {
    const url = String(req.body?.url || "").trim();
    const typedKey = String(req.body?.siteKey || "").trim();
    const result = await readGoogleStats(url, typedKey);
    const hasSummary = Object.values(result.summary).every(Boolean);
    const insightData = {
      period: result.period,
      summary: result.summary,
      devices: result.devices
    };
    const [nhanDinh, nhanDinhThietBi] = await Promise.all([
      hasSummary ? nhanDinhThongKe(insightData) : Promise.resolve([]),
      result.devices.length ? nhanDinhThongKe(insightData, "devices") : Promise.resolve([])
    ]);
    res.json({ ...result, nhanDinh, nhanDinhThietBi });
  } catch (error) { sendError(res, error); }
});
app.post("/api/stats/logout", async (_req, res) => {
  try { res.json(await logoutGoogle()); } catch (error) { sendError(res, error); }
});

function sendError(res: express.Response, error: unknown): void {
  res.status(400).json({ error: error instanceof Error ? error.message : "Đã có lỗi khi xử lý." });
}

function compareDomain(input: string): string {
  try {
    const value = /^[a-z][a-z\d+.-]*:\/\//i.test(input) ? input : `https://${input}`;
    return new URL(value).hostname.toLowerCase().replace(/^www\./, "").replace(/\.$/, "");
  } catch {
    throw new Error("Địa chỉ website không hợp lệ.");
  }
}

function compareError(error: unknown): string {
  const message = error instanceof Error ? error.message : "";
  if (message.includes("Không tìm thấy website")) return "Tên miền không phân giải được hoặc website không phản hồi mạng.";
  if (message.includes("Không kết nối được website")) return "Website không phản hồi kết nối mạng.";
  if (message.includes("Địa chỉ website không hợp lệ")) return "Địa chỉ website không hợp lệ hoặc thiếu tên miền.";
  if (message.includes("phản hồi quá thời gian")) return "Website phản hồi chậm quá 15 giây.";
  return message || "Không tải được website do lỗi mạng.";
}

if (existsSync(resolve(root, "dist/index.html"))) {
  app.use(express.static(resolve(root, "dist")));
  app.get("*", (_req, res) => res.status(200).sendFile(resolve(root, "dist/index.html")));
} else {
  const vite = await createViteServer({ configFile: resolve(root, "vite.config.ts"), server: { middlewareMode: true }, appType: "spa" });
  app.use(vite.middlewares);
  app.get("*", (_req, res) => res.status(200).sendFile(resolve(root, "index.html")));
}

const port = 3000;
app.listen(port, "127.0.0.1", () => console.log(`Ong Nhỏ đang chạy tại http://localhost:${port}`));
