import puppeteer, { type Browser, type Page } from "puppeteer-core";
import { access } from "node:fs/promises";
import { delimiter, join } from "node:path";
import { validatePublicUrl } from "./fetchPage.js";

export type Rect = { id: "h1" | "h2" | "noi_dung" | "anh_alt" | "cta" | "lien_he" | "tel" | "chinh_ta" | "dieu_huong"; x: number; y: number; w: number; h: number; approximate?: boolean };
export type ExtraShot = { id: number; anh: string; rects: Rect[] };
export type SpellingShot = { tuSai: string; anh: string; rect: Rect };
export type ShotResult = {
  anh: string | null;
  rects: Rect[];
  anhPhu: ExtraShot[];
  anhChinhTa: SpellingShot[];
  loi?: string;
};
type SpellingError = { tuSai: string; cauChuaTu: string };
type PdfFinding = {
  id: number;
  nhom: string;
  ten: string;
  diemDat: number;
  diemToiDa: number;
  trangThai: string;
  tinhTrang: string;
  yNghia: string;
  rect?: Rect | Rect[];
};
type ReviewLinks = { diemManh?: number[][]; diemYeu?: number[][] };
type PdfAudit = {
  score: number;
  title: string;
  page: { url: string; finalUrl: string };
  findings: PdfFinding[];
  groupScores: Array<{ nhom: string; diem: number; diemToiDa: number }>;
  anh: string | null;
  rects: Rect[];
  nhanXet: { diemManh: string[]; diemYeu: string[]; tieuChiLienQuan?: ReviewLinks };
  loiChinhTa: Array<{ tuSai: string; cauChuaTu: string }>;
  anhPhu?: ExtraShot[];
  anhChinhTa?: SpellingShot[];
};
type PdfInput = {
  audit: PdfAudit;
  previous?: { createdAt: string; audit: PdfAudit } | null;
};

const VIEWPORT = { width: 1366, height: 800 };
const MAX_DURATION_MS = 45_000;
let browser: Browser | undefined;
let browserLaunch: Promise<Browser> | undefined;

async function browserPath(): Promise<string> {
  const home = process.env.HOME || "";
  const candidates = [
    process.env.CHROME_PATH,
    process.env.LOCALAPPDATA ? join(process.env.LOCALAPPDATA, "Google/Chrome/Application/chrome.exe") : "",
    "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
    "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
    "C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe",
    "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe",
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
    "/usr/bin/google-chrome",
    "/usr/bin/google-chrome-stable",
    "/usr/bin/chromium",
    "/usr/bin/chromium-browser",
    "/snap/bin/chromium",
    home ? join(home, "Applications/Google Chrome.app/Contents/MacOS/Google Chrome") : "",
    ...(process.env.PATH || "").split(delimiter).flatMap(dir => [
      join(dir, "chrome"),
      join(dir, "google-chrome"),
      join(dir, "chromium"),
      join(dir, "msedge")
    ])
  ].filter((path): path is string => Boolean(path));
  for (const path of candidates) {
    try { await access(path); return path; } catch { /* Kiểm tra trình duyệt tiếp theo. */ }
  }
  throw new Error("Không tìm thấy Chrome hoặc Edge. Có thể đặt đường dẫn trong CHROME_PATH.");
}

async function getBrowser(): Promise<Browser> {
  if (browser?.isConnected()) return browser;
  if (!browserLaunch) {
    browserLaunch = (async () => {
      const executablePath = await browserPath();
      const instance = await puppeteer.launch({
        executablePath,
        headless: true,
        timeout: 30_000,
        args: process.platform === "linux" ? ["--no-sandbox"] : []
      });
      browser = instance;
      instance.once("disconnected", () => { if (browser === instance) browser = undefined; });
      return instance;
    })().finally(() => { browserLaunch = undefined; });
  }
  return browserLaunch;
}

async function findRects(page: Page): Promise<Rect[]> {
  return page.evaluate(() => {
    type Kind = Rect["id"];
    const found: Rect[] = [];
    const candidates: Array<[Element | null, Kind]> = [[document.querySelector("h1"), "h1"]];
    for (const image of [...document.querySelectorAll("img")].filter(img => !img.getAttribute("alt")?.trim()).slice(0, 6)) {
      candidates.push([image, "anh_alt"]);
    }
    const words = ["gọi", "đặt", "liên hệ", "mua", "đăng ký", "tư vấn", "báo giá", "call", "contact", "buy"];
    const actions = [...document.querySelectorAll("a, button")];
    const cta = actions.find(element => {
      const label = `${(element as HTMLElement).innerText || ""} ${element.getAttribute("aria-label") || ""}`.toLocaleLowerCase("vi");
      return words.some(word => label.includes(word));
    });
    candidates.push([cta || null, "cta"]);
    candidates.push([document.querySelector("nav") || document.querySelector("header"), "dieu_huong"]);
    for (const [element, id] of candidates) {
      if (!element) continue;
      const style = getComputedStyle(element);
      if (style.display === "none" || style.visibility === "hidden" || Number(style.opacity) === 0) continue;
      const box = element.getBoundingClientRect();
      const left = Math.max(0, box.left);
      const top = Math.max(0, box.top);
      const right = Math.min(innerWidth, box.right);
      const bottom = Math.min(innerHeight, box.bottom);
      if (right <= left || bottom <= top) continue;
      found.push({
        id,
        x: left / innerWidth * 100,
        y: top / innerHeight * 100,
        w: (right - left) / innerWidth * 100,
        h: (bottom - top) / innerHeight * 100
      });
    }
    return found;
  });
}

function selectorForCriterion(id: number): string {
  const selectors: Record<number, string> = {
    3: "h1", 4: "h2", 5: "img:not([alt]), img[alt='']",
    6: "main p, article p", 21: "a, button",
    22: "a[href^='tel:'], a[href^='mailto:'], address, [itemprop='address']",
    23: "a[href^='tel:']", 25: "nav, [role='navigation'], header"
  };
  return selectors[id] || "";
}
const criterionRectIds: Record<number, Rect["id"]> = {
  3: "h1", 4: "h2", 5: "anh_alt", 6: "noi_dung", 21: "cta", 22: "lien_he", 23: "tel", 25: "dieu_huong"
};

async function scrollToCriterion(page: Page, id: number): Promise<Rect | null> {
  const selector = selectorForCriterion(id);
  if (!selector) return null;
  return page.evaluate((target, criterion, rectId) => {
    const words = ["gọi", "đặt", "liên hệ", "mua", "đăng ký", "tư vấn", "báo giá", "call", "contact", "buy"];
    const elements = criterion === 5
      ? [...document.querySelectorAll("img")].filter(image => !image.getAttribute("alt")?.trim())
      : [...document.querySelectorAll(target)];
    const isVisible = (item: Element) => {
      const style = getComputedStyle(item);
      const box = item.getBoundingClientRect();
      return style.display !== "none" && style.visibility !== "hidden" && Number(style.opacity) !== 0 &&
        box.width > 0 && box.height > 0;
    };
    const labelOf = (item: Element) => `${(item as HTMLElement).innerText || ""} ${item.getAttribute("aria-label") || ""}`.trim();
    const element = criterion === 21
      ? elements.find(item => isVisible(item) && words.some(word => labelOf(item).toLocaleLowerCase("vi").includes(word)))
      : elements.find(item => isVisible(item) && (criterion !== 25 ||
        item.matches("nav,[role='navigation']") || item.querySelectorAll("a,button,[role='link'],[role='button']").length >= 2));
    let selected = element;
    let approximate = false;
    if (!selected) {
      const candidateSelectors: Record<number, string> = {
        3: "h2,h3,h4,[role='heading']",
        4: "h3,h4,h1,[role='heading']",
        5: "main img,article img,img",
        6: "main,article,[role='main'],section,p",
        21: "button,a,[role='button']",
        22: "address,footer,[id*='contact' i],[class*='contact' i],main,section",
        23: "[itemprop='telephone'],address,footer,main,p",
        25: "[role='navigation'],nav,header,ul"
      };
      const candidates = [...document.querySelectorAll(candidateSelectors[criterion] || "")]
        .filter(item => isVisible(item));
      const relevant = candidates.filter(item => {
        const label = labelOf(item);
        if (criterion === 3 || criterion === 4) return true;
        if (criterion === 5) return item instanceof HTMLImageElement && item.naturalWidth > 0;
        if (criterion === 6) return label.length >= 40;
        if (criterion === 21) return label.length > 0;
        if (criterion === 22) return /liên hệ|contact|địa chỉ|address|email|e-mail|điện thoại|phone/i.test(label);
        if (criterion === 23) return /(?:\+?84|0)(?:[\s().-]*\d){8,10}\b/.test(label);
        if (criterion === 25) return item.querySelectorAll("a,button,[role='link'],[role='button']").length >= 2;
        return false;
      });
      if (criterion === 3 || criterion === 4) {
        selected = relevant[0];
      } else if (criterion === 5) {
        selected = relevant.sort((a, b) => {
          const boxA = a.getBoundingClientRect(), boxB = b.getBoundingClientRect();
          const mainA = a.closest("main,article") ? 1 : 0, mainB = b.closest("main,article") ? 1 : 0;
          return mainB - mainA || boxB.width * boxB.height - boxA.width * boxA.height;
        })[0];
      } else if (criterion === 6) {
        selected = relevant.sort((a, b) => Math.abs(labelOf(a).length - 350) - Math.abs(labelOf(b).length - 350))[0];
      } else if (criterion === 21) {
        const genericActions = ["liên hệ", "contact", "gọi", "call", "đặt", "mua", "đăng ký", "tư vấn", "báo giá", "learn more", "get started", "read more", "submit", "book", "shop"];
        selected = relevant.find(item => genericActions.some(word => labelOf(item).toLocaleLowerCase("vi").includes(word))) ||
          relevant.find(item => item.matches("button,[role='button']"));
      } else if (criterion === 22 || criterion === 23) {
        selected = relevant.sort((a, b) => labelOf(a).length - labelOf(b).length)[0];
      } else if (criterion === 25) {
        selected = relevant.sort((a, b) => a.querySelectorAll("a,button,[role='link'],[role='button']").length -
          b.querySelectorAll("a,button,[role='link'],[role='button']").length)[0];
      }
      approximate = Boolean(selected);
    }
    if (!selected) return null;
    selected.scrollIntoView({ block: "center" });
    return new Promise<Rect | null>(resolve => requestAnimationFrame(() => {
      const box = selected.getBoundingClientRect();
      const x = Math.max(0, box.left), y = Math.max(0, box.top);
      const right = Math.min(innerWidth, box.right), bottom = Math.min(innerHeight, box.bottom);
      resolve(right > x && bottom > y ? {
        id: rectId || "h1", x: x / innerWidth * 100, y: y / innerHeight * 100,
        w: (right - x) / innerWidth * 100, h: (bottom - y) / innerHeight * 100, ...(approximate ? { approximate: true } : {})
      } : null);
    }));
  }, selector, id, criterionRectIds[id]);
}

async function scrollToSpelling(page: Page, word: string): Promise<Rect | null> {
  return page.evaluate((target): Promise<Rect | null> => {
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let node: Text | null;
    while ((node = walker.nextNode() as Text | null)) {
      const parent = node.parentElement;
      if (!parent || /^(SCRIPT|STYLE|NOSCRIPT|TEMPLATE)$/i.test(parent.tagName)) continue;
      let hidden = false;
      for (let element: Element | null = parent; element; element = element.parentElement) {
        const style = getComputedStyle(element);
        if (style.display === "none" || style.visibility === "hidden" || Number(style.opacity) === 0) { hidden = true; break; }
      }
      if (hidden) continue;
      const offset = node.data.toLocaleLowerCase().indexOf(target.toLocaleLowerCase());
      if (offset < 0) continue;
      const range = document.createRange();
      range.setStart(node, offset);
      range.setEnd(node, offset + target.length);
      parent.scrollIntoView({ block: "center" });
      return new Promise(resolve => requestAnimationFrame(() => {
        const box = range.getBoundingClientRect();
        const x = Math.max(0, box.left), y = Math.max(0, box.top);
        const right = Math.min(innerWidth, box.right), bottom = Math.min(innerHeight, box.bottom);
        if (right <= x || bottom <= y) return resolve(null);
        const rect: Rect = { id: "chinh_ta", x: x / innerWidth * 100, y: y / innerHeight * 100, w: (right - x) / innerWidth * 100, h: (bottom - y) / innerHeight * 100 };
        const marker = document.createElement("span");
        marker.dataset.ongNhoMarker = "true";
        Object.assign(marker.style, {
          position: "fixed", left: `${x}px`, top: `${y}px`, width: `${right - x}px`,
          height: `${bottom - y}px`, border: "2px solid #d73527", borderRadius: "3px",
          zIndex: "2147483647", pointerEvents: "none"
        });
        document.body.append(marker);
        resolve(rect);
      }));
    }
    return Promise.resolve(null);
  }, word);
}

async function openPage(url: string): Promise<{ page: Page; close: () => Promise<void> }> {
  const safeUrl = await validatePublicUrl(url);
  const instance = await getBrowser();
  const page = await instance.newPage();
  await page.setViewport({ ...VIEWPORT, deviceScaleFactor: 1 });
  page.setDefaultNavigationTimeout(15_000);
  await page.setRequestInterception(true);
  page.on("request", async request => {
    const resource = request.url();
    if (/^(data|blob|about|chrome):/i.test(resource)) return request.continue();
    try {
      await validatePublicUrl(resource);
      await request.continue();
    } catch {
      await request.abort();
    }
  });
  try {
    await page.goto(safeUrl.toString(), { waitUntil: "load", timeout: 15_000 });
    return { page, close: () => page.close() };
  } catch (error) {
    await page.close();
    throw error;
  }
}

async function capture(
  url: string,
  extraIds: number[] | Promise<number[]> = [],
  spelling: SpellingError[] = [],
  includePrimary = true,
  quality = 70
): Promise<ShotResult> {
  const opened = await openPage(url);
  try {
    const { page } = opened;
    const [rects, anh] = includePrimary
      ? await Promise.all([
        findRects(page),
        page.screenshot({ type: "jpeg", quality, fullPage: false, encoding: "base64" })
      ])
      : [[], null];
    const anhPhu: ExtraShot[] = [];
    const primaryRectIds = new Set(rects.map(rect => rect.id));
    const requestedIds = await extraIds;
    for (const id of [...new Set(requestedIds)].filter(itemId => {
      const rectId = criterionRectIds[itemId];
      return !rectId || !primaryRectIds.has(rectId);
    }).slice(0, 8)) {
      const rect = await scrollToCriterion(page, id);
      if (!rect) continue;
      const image = await page.screenshot({ type: "jpeg", quality, fullPage: false, encoding: "base64" });
      anhPhu.push({ id, anh: image, rects: [rect] });
    }
    const anhChinhTa: SpellingShot[] = [];
    for (const item of spelling.slice(0, 3)) {
      const rect = await scrollToSpelling(page, item.tuSai);
      if (!rect) continue;
      const image = await page.screenshot({ type: "jpeg", quality, fullPage: false, encoding: "base64" });
      await page.evaluate(() => document.querySelectorAll("[data-ong-nho-marker]").forEach(node => node.remove()));
      anhChinhTa.push({ tuSai: item.tuSai, anh: image, rect });
    }
    return { anh, rects, anhPhu, anhChinhTa };
  } finally {
    await opened.close();
  }
}

async function captureWithTimeout(
  url: string,
  extraIds: number[] | Promise<number[]>,
  spelling: SpellingError[],
  includePrimary = true,
  quality = 70
): Promise<ShotResult> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  try {
    const timeout = new Promise<never>((_resolve, reject) => {
      timer = setTimeout(() => reject(new Error("Quá thời gian chụp ảnh 45 giây.")), MAX_DURATION_MS);
    });
    return await Promise.race([capture(url, extraIds, spelling, includePrimary, quality), timeout]);
  } catch (error) {
    console.error("[SHOT]", error);
    const detail = error instanceof Error ? error.message : String(error);
    const loi = /45 giây/i.test(detail) || /15\d{3} ms|navigation timeout/i.test(detail)
      ? "Trang tải lâu hơn thời gian chờ, không chụp được ảnh."
      : /chrome|edge|browser executable|failed to launch/i.test(detail)
        ? "Không tìm thấy hoặc không mở được Chrome/Edge. Có thể đặt đường dẫn trong CHROME_PATH."
        : /net::|protocol error|target closed|connection closed/i.test(detail)
          ? "Không tải được trang trong trình duyệt. Kiểm tra địa chỉ và kết nối mạng."
          : detail;
    return {
      anh: null,
      rects: [],
      anhPhu: [],
      anhChinhTa: [],
      loi: `${loi || "Không chụp được ảnh website."}${detail ? ` (${detail.slice(0, 120)})` : ""}`
    };
  } finally {
    if (timer) clearTimeout(timer);
  }
}

export async function chupTrang(url: string, extraIds: Promise<number[]> = Promise.resolve([]), quality = 70): Promise<ShotResult> {
  return captureWithTimeout(url, extraIds, [], true, quality);
}

export async function chupPhanTu(url: string, ids: number[], spelling: SpellingError[]): Promise<Pick<ShotResult, "anhPhu" | "anhChinhTa">> {
  const result = await captureWithTimeout(url, ids, spelling, false, 60);
  return { anhPhu: result.anhPhu, anhChinhTa: result.anhChinhTa };
}

export async function createShot(url: string): Promise<{ image: string; pdf: string }> {
  const result = await chupTrang(url);
  return { image: result.anh ? `data:image/jpeg;base64,${result.anh}` : "", pdf: "" };
}
function escapeHtml(value: unknown): string {
  return String(value ?? "").replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[char] || char);
}

function imageData(value: string | null | undefined): string {
  if (!value) return "";
  const raw = value.replace(/^data:image\/(?:jpeg|png);base64,/i, "");
  return /^[A-Za-z0-9+/]+={0,2}$/.test(raw) ? `data:image/jpeg;base64,${raw}` : "";
}
function reportImage(audit: PdfAudit, finding: PdfFinding): string {
  const extra = audit.anhPhu?.find(item => item.id === finding.id);
  const image = imageData(extra?.anh || audit.anh);
  if (!image) return `<div class="note">${escapeHtml(finding.tinhTrang)}<br>Không có ảnh chụp cho lần kiểm tra này.</div>`;
  const rects = finding.trangThai === "khong_ap_dung" ? [] : extra?.rects || (finding.rect ? Array.isArray(finding.rect) ? finding.rect : [finding.rect] : audit.rects.filter(rect => {
    const ids: Record<number, string> = { 3: "h1", 5: "anh_alt", 21: "cta", 25: "dieu_huong" };
    return rect.id === ids[finding.id];
  }));
  const percent = (value: number) => Number.isFinite(value) ? Math.max(0, Math.min(100, value)) : 0;
  const tone = finding.trangThai === "dat" ? "#168447" : finding.trangThai === "mot_phan" ? "#1769aa" : "#c53030";
  const markers = rects.map((rect, index) => `<i style="left:${percent(rect.x)}%;top:${percent(rect.y)}%;width:${percent(rect.w)}%;height:${percent(rect.h)}%;border-color:${tone}"><b style="background:${tone}">${index + 1}</b></i>`).join("");
  const notes = rects.map((rect, index) => `<div class="marker-note"><b style="color:${tone}">${index + 1}.</b> ${escapeHtml(finding.ten)} · ${escapeHtml(finding.tinhTrang)}${rect.approximate ? " · chưa xác định chính xác vị trí." : ""}</div>`).join("");
  return `<div class="thumb"><img src="${image}">${markers}</div>${rects.length ? `<div class="marker-notes">${notes}</div>` : `<div class="note">${escapeHtml(finding.tinhTrang)}<br>Không tìm thấy vùng phù hợp để đánh dấu.</div>`}`;
}
function reportRows(audit: PdfAudit): string {
  return audit.findings.map(item => `<tr>
    <td>${escapeHtml(item.nhom)}</td>
    <td><b>${escapeHtml(item.ten)}</b><div class="sub">${escapeHtml(item.tinhTrang)}</div><div class="sub">${escapeHtml(item.yNghia)}</div></td>
    <td>${escapeHtml(item.diemDat)}/${escapeHtml(item.diemToiDa)}<div class="sub">${statusLabel(item.trangThai)}</div></td>
    <td>${reportImage(audit, item)}</td>
  </tr>`).join("");
}
function reportReview(audit: PdfAudit, strong: boolean): Array<{ line: string; ids: number[] }> {
  const saved = strong ? audit.nhanXet.diemManh : audit.nhanXet.diemYeu;
  const fallback = audit.findings.filter(item => item.diemToiDa > 0 && item.trangThai !== "khong_ap_dung")
    .sort((a, b) => strong
      ? b.diemDat / b.diemToiDa - a.diemDat / a.diemToiDa
      : a.diemDat / a.diemToiDa - b.diemDat / b.diemToiDa);
  return (saved.length ? saved.slice(0, 3) : fallback.slice(0, 3).map(item => `${item.ten}: ${item.tinhTrang}.`))
    .map((line, index) => {
      const links = audit.nhanXet.tieuChiLienQuan?.[strong ? "diemManh" : "diemYeu"]?.[index] || [];
      const ids = links.filter(id => audit.findings.some(item => item.id === id)).slice(0, 2);
      return { line, ids: ids.length ? ids : [fallback[index]?.id].filter((id): id is number => id !== undefined) };
    });
}

function statusLabel(status: string): string {
  return status === "dat" ? "Đạt" : status === "mot_phan" ? "Một phần" : status === "khong_ap_dung" ? "Không áp dụng" : "Chưa đạt";
}
function comparison(input: PdfInput): string {
  if (!input.previous) return "";
  const before = input.previous.audit;
  const after = input.audit;
  const groupChanges = after.groupScores.map(group => {
    const old = before.groupScores.find(item => item.nhom === group.nhom);
    const delta = group.diem - (old?.diem ?? 0);
    return { name: group.nhom, delta };
  }).filter(item => item.delta !== 0);
  const criterionChanges = after.findings.map(item => {
    const old = before.findings.find(previous => previous.id === item.id);
    return old ? { name: item.ten, delta: item.diemDat - old.diemDat } : null;
  }).filter((item): item is { name: string; delta: number } => item !== null && item.delta !== 0);
  const scoreDelta = after.score - before.score;
  const noChanges = scoreDelta === 0 && !groupChanges.length && !criterionChanges.length;
  const list = (title: string, values: Array<{ name: string; delta: number }>) =>
    values.length ? `<h3>${title}</h3><ul>${values.map(item => `<li>${escapeHtml(item.name)}: ${item.delta > 0 ? "+" : ""}${item.delta} điểm</li>`).join("")}</ul>` : "";
  const beforeImage = imageData(before.anh);
  const afterImage = imageData(after.anh);
  return `<section class="page-break"><h2>So sánh trước và sau</h2>
    ${noChanges ? `<p class="unchanged">Chưa có thay đổi so với lần trước</p>` : `<p>Điểm tổng thể: ${before.score}/100 → ${after.score}/100 (${scoreDelta > 0 ? "+" : ""}${scoreDelta})</p>${list("Nhóm thay đổi", groupChanges)}${list("Tiêu chí thay đổi", criterionChanges)}`}
    <div class="before-after"><div><h3>Lần trước · ${escapeHtml(new Date(input.previous.createdAt).toLocaleString("vi-VN"))}</h3>${beforeImage ? `<img src="${beforeImage}">` : `<div class="note">Lần trước không có ảnh lưu.</div>`}</div>
    <div><h3>Lần này</h3>${afterImage ? `<img src="${afterImage}">` : `<div class="note">Lần này không có ảnh chụp.</div>`}</div></div>
  </section>`;
}
function reportHtml(input: PdfInput): string {
  const audit = input.audit;
  const spelling = audit.loiChinhTa.length
    ? `<ul>${audit.loiChinhTa.map((item, index) => {
      const shot = audit.anhChinhTa?.find(image => image.tuSai === item.tuSai);
      const image = imageData(shot?.anh);
      const marker = shot ? `<i style="left:${shot.rect.x}%;top:${shot.rect.y}%;width:${shot.rect.w}%;height:${shot.rect.h}%;border-color:#c53030"><b style="background:#c53030">${index + 1}</b></i>` : "";
      return `<li><b>${index + 1}. ${escapeHtml(item.tuSai)}</b> · ${escapeHtml(item.cauChuaTu)}${image ? `<div class="thumb spelling"><img src="${image}">${marker}</div>` : `<div class="note">Không có ảnh đánh dấu lỗi này.</div>`}</li>`;
    }).join("")}</ul>`
    : "<p>Không phát hiện lỗi chính tả.</p>";
  const groups = audit.groupScores.map(group => `<div class="group"><b>${escapeHtml(group.nhom)}</b><span>${group.diem}/${group.diemToiDa}</span></div>`).join("");
  const review = (strong: boolean) => reportReview(audit, strong).map(item => {
    const pictures = item.ids.map(id => {
      const finding = audit.findings.find(entry => entry.id === id);
      return finding ? reportImage(audit, finding) : "";
    }).join("");
    return `<li>${escapeHtml(item.line)}${pictures}</li>`;
  }).join("");
  const strengths = review(true);
  const weaknesses = review(false);
  return `<!doctype html><html lang="vi"><meta charset="utf-8"><style>
    @page{size:A4;margin:14mm}*{box-sizing:border-box}body{font:12px "Times New Roman",Times,serif;color:#2B1B0E;margin:0}
    h1{font-size:25px;margin:0;color:#2B1B0E}h2{font-size:17px;margin:18px 0 9px;border-bottom:2px solid #FFB400;padding-bottom:5px}
    h3{font-size:12px;margin:8px 0}p{line-height:1.45;margin:5px 0}.brand{display:flex;align-items:center;gap:10px;border-bottom:3px solid #FFB400;padding-bottom:12px}
    .bee{font-size:28px}.meta{display:grid;grid-template-columns:1fr 1fr;gap:4px 16px;margin:12px 0}
    .score{font-size:22px;font-weight:bold;color:#8a5900}.groups{display:grid;grid-template-columns:repeat(2,1fr);gap:6px 12px}
    .group{display:flex;justify-content:space-between;padding:6px;background:#FFF8E7}.sub{color:#655b4e;margin-top:3px;font-size:10px;line-height:1.35}
    table{width:100%;border-collapse:collapse;table-layout:fixed}th,td{border:1px solid #ddcfb8;padding:6px;vertical-align:top}th{background:#FFF3D1;text-align:left}
    th:nth-child(1){width:15%}th:nth-child(2){width:42%}th:nth-child(3){width:12%}th:nth-child(4){width:31%}
    .thumb{position:relative;width:100%;height:72px;overflow:hidden;background:#FFF8E7}.thumb img{width:100%;height:100%;object-fit:contain}
    .thumb i{position:absolute;border:2px solid;border-radius:3px}.thumb i b{position:absolute;top:-1px;left:-1px;display:grid;min-width:18px;height:18px;place-items:center;border-radius:50%;color:#fff;font-size:10px}.thumb.spelling{max-width:320px;margin-top:5px}.note{font-size:10px;color:#514638;background:#FFF8E7;padding:5px;margin-top:4px;line-height:1.4}.marker-note{font-size:10px;line-height:1.4;margin-top:3px}
    .cols{display:grid;grid-template-columns:1fr 1fr;gap:18px}.page-break{page-break-before:always}.before-after{display:grid;grid-template-columns:1fr 1fr;gap:12px}
    .before-after img{width:100%;border:0}.unchanged{padding:10px;background:#FFF8E7;font-weight:bold}
    li{margin:4px 0}section{page-break-inside:avoid}
  </style><body>
    <header class="brand"><span class="bee">🐝</span><div><h1>Ong Nhỏ</h1><p>Báo cáo tình trạng website</p></div></header>
    <div class="meta"><span><b>Ngày giờ:</b> ${escapeHtml(new Date().toLocaleString("vi-VN"))}</span><span><b>Địa chỉ:</b> ${escapeHtml(audit.page.finalUrl || audit.page.url)}</span></div>
    <p class="score">Điểm tổng thể: ${audit.score}/100</p><h2>Điểm theo nhóm</h2><div class="groups">${groups}</div>
    <h2>25 tiêu chí</h2><table><thead><tr><th>Nhóm</th><th>Tình trạng và ý nghĩa</th><th>Điểm</th><th>Ảnh hoặc ghi chú</th></tr></thead><tbody>${reportRows(audit)}</tbody></table>
    <div class="cols"><section><h2>3 điểm mạnh</h2><ul>${strengths || "<li>Chưa có dữ liệu.</li>"}</ul></section><section><h2>3 điểm còn yếu</h2><ul>${weaknesses || "<li>Chưa có dữ liệu.</li>"}</ul></section></div>
    <section><h2>Kiểm tra chính tả</h2>${spelling}</section>
    ${comparison(input)}</body></html>`;
}

export async function createPdf(input: PdfInput): Promise<Uint8Array> {
  if (!input?.audit || !Array.isArray(input.audit.findings) || !Array.isArray(input.audit.groupScores)) throw new Error("Dữ liệu báo cáo không hợp lệ.");
  try {
    const instance = await getBrowser();
    const page = await instance.newPage();
    try {
      await page.setContent(reportHtml(input), { waitUntil: "load", timeout: 15_000 });
      return await page.pdf({ format: "A4", printBackground: true });
    } finally { await page.close(); }
  } catch (error) {
    console.error("[PDF]", error);
    throw new Error("Không tạo được PDF: " + (error instanceof Error ? error.message.split("\n")[0].slice(0, 140) : "lỗi không rõ"));
  }
}
