import type { PageData } from "./fetchPage.js";

export type CriterionStatus = "dat" | "mot_phan" | "chua_dat" | "khong_ap_dung";
export type Criterion = {
  id: number;
  nhom: string;
  ten: string;
  diemToiDa: number;
  diemDat: number;
  trangThai: CriterionStatus;
  tinhTrang: string;
  yNghia: string;
  nhinThay: boolean;
  name: string;
  status: "tốt" | "chú ý";
  meaning: string;
  points: number;
};
export type Finding = Pick<Criterion, "name" | "status" | "meaning">;
export type Audit = {
  score: number;
  findings: Criterion[];
  title: string;
  groupScores: Array<{ nhom: string; diem: number; diemToiDa: number }>;
  canhBaoJS: boolean;
  giaiThichJS: string;
};

type Check = {
  nhom: string;
  ten: string;
  diemToiDa: number;
  diemDat: number;
  tinhTrang: string;
  yNghia: string;
  nhinThay: boolean;
  khongApDung?: boolean;
  motPhan?: boolean;
};

const GROUPS = [
  { nhom: "Nội dung", diemToiDa: 30 },
  { nhom: "Kỹ thuật & tìm kiếm", diemToiDa: 25 },
  { nhom: "Di động & tốc độ", diemToiDa: 15 },
  { nhom: "Mạng xã hội", diemToiDa: 10 },
  { nhom: "Giao diện & trải nghiệm", diemToiDa: 20 }
];

function decode(value: string): string {
  return value
    .replace(/&nbsp;|&#160;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/&#(\d+);/g, (_match, number: string) => String.fromCodePoint(Number(number)))
    .replace(/&#x([\da-f]+);/gi, (_match, number: string) => String.fromCodePoint(parseInt(number, 16)));
}

function attributes(tag: string): Record<string, string> {
  const result: Record<string, string> = {};
  const pattern = /([^\s=/>]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+)))?/g;
  let match: RegExpExecArray | null;
  while ((match = pattern.exec(tag.slice(tag.indexOf(" ") + 1)))) {
    result[match[1].toLowerCase()] = decode(match[2] ?? match[3] ?? match[4] ?? "");
  }
  return result;
}

function tags(html: string, name: string): string[] {
  return [...html.matchAll(new RegExp(`<${name}\\b[^>]*>`, "gi"))].map(match => match[0]);
}

function visibleText(html: string): string {
  return decode(html
    .replace(/<!--[\s\S]*?-->/g, " ")
    .replace(/<head\b[^>]*>[\s\S]*?<\/head\s*>/gi, " ")
    .replace(/<(script|style|template|noscript)\b[^>]*>[\s\S]*?<\/\1\s*>/gi, " ")
    .replace(/<([a-z][\w:-]*)\b(?=[^>]*(?:hidden\b|aria-hidden=["']true["']|display\s*:\s*none|visibility\s*:\s*hidden))[^>]*>[\s\S]*?<\/\1\s*>/gi, " ")
    .replace(/<[^>]*>/g, " "))
    .replace(/\s+/g, " ")
    .trim();
}

function contentOf(html: string, tag: string): string[] {
  return [...html.matchAll(new RegExp(`<${tag}\\b[^>]*>([\\s\\S]*?)<\\/${tag}\\s*>`, "gi"))]
    .map(match => visibleText(match[1]));
}

function metaContent(html: string, key: string, attribute: "name" | "property" = "name"): string {
  for (const tag of tags(html, "meta")) {
    const attrs = attributes(tag);
    if (attrs[attribute]?.toLowerCase() === key) return attrs.content || "";
  }
  return "";
}

function countWords(value: string): number {
  return value.match(/[\p{L}\p{N}]+/gu)?.length || 0;
}

function makeCheck(
  nhom: string, ten: string, diemToiDa: number, diemDat: number,
  tinhTrang: string, yNghia: string, nhinThay: boolean,
  options: { khongApDung?: boolean; motPhan?: boolean } = {}
): Check {
  return { nhom, ten, diemToiDa, diemDat, tinhTrang, yNghia, nhinThay, ...options };
}

function getChecks(page: PageData): Check[] {
  const html = page.html;
  const plain = visibleText(html);
  const title = contentOf(html, "title")[0] || "";
  const description = metaContent(html, "description").trim();
  const h1 = contentOf(html, "h1");
  const h2 = contentOf(html, "h2");
  const images = tags(html, "img");
  const imagesWithAlt = images.filter(tag => Boolean(attributes(tag).alt?.trim())).length;
  const words = countWords(plain);
  const viewport = tags(html, "meta").some(tag => {
    const attrs = attributes(tag);
    return attrs.name?.toLowerCase() === "viewport" && /width\s*=\s*device-width/i.test(attrs.content || "");
  });
  const scripts = tags(html, "script");
  const jsonLd = scripts.filter(tag => attributes(tag)["type"]?.toLowerCase() === "application/ld+json");
  let jsonLdValid = false;
  for (const tag of jsonLd) {
    const match = new RegExp(`${tag.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}([\\s\\S]*?)<\\/script\\s*>`, "i").exec(html);
    if (!match) continue;
    try { JSON.parse(decode(match[1])); jsonLdValid = true; break; } catch { /* Invalid JSON-LD is counted below. */ }
  }
  const noindex = tags(html, "meta").some(tag => {
    const attrs = attributes(tag);
    return ["robots", "googlebot"].includes((attrs.name || "").toLowerCase()) && /\bnoindex\b/i.test(attrs.content || "");
  });
  const visibleImages = images.filter(tag => !/\bhidden\b|display\s*:\s*none|visibility\s*:\s*hidden/i.test(tag));
  const anchors = [...html.matchAll(/<a\b([^>]*)>([\s\S]*?)<\/a\s*>/gi)];
  const buttons = [...html.matchAll(/<button\b([^>]*)>([\s\S]*?)<\/button\s*>/gi)];
  const ctaVietnamese = ["gọi", "đặt", "liên hệ", "mua", "đăng ký", "tư vấn", "báo giá"];
  const hasCta = [...anchors, ...buttons].some(match => {
    const attrs = attributes(`<a ${match[1]}>`);
    const label = `${visibleText(match[2])} ${attrs["aria-label"] || ""}`.toLocaleLowerCase("vi");
    const displayed = !("hidden" in attrs) && attrs["aria-hidden"] !== "true" &&
      !/display\s*:\s*none|visibility\s*:\s*hidden/i.test(attrs.style || "");
    return displayed && (ctaVietnamese.some(word => label.includes(word)) || /\b(call|contact|buy)\b/i.test(label));
  });
  const phone = /(?:\+?84|0)(?:[\s().-]*\d){8,10}\b/.test(plain);
  const email = /\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/i.test(plain);
  const address = /\bđịa chỉ\b/i.test(plain) || /<address\b|itemprop=["'](?:streetAddress|address)["']/i.test(html);
  const contactCount = Number(phone) + Number(email) + Number(address);
  const telephoneLink = tags(html, "a").some(tag => /^tel:/i.test(attributes(tag).href || ""));
  const headerHasMenu = [...html.matchAll(/<header\b[^>]*>[\s\S]*?<\/header\s*>/gi)]
    .some(match => [...match[0].matchAll(/<a\b/gi)].length >= 3);
  const nav = tags(html, "nav").length > 0 || headerHasMenu;
  const favicon = tags(html, "link").some(tag => /\bicon\b/i.test(attributes(tag).rel || ""));
  const group1 = "Nội dung";
  const group2 = "Kỹ thuật & tìm kiếm";
  const group3 = "Di động & tốc độ";
  const group4 = "Mạng xã hội";
  const group5 = "Giao diện & trải nghiệm";

  return [
    makeCheck(group1, "Tiêu đề trang", 7, !title ? 0 : title.length >= 30 && title.length <= 60 ? 7 : 4,
      title ? `Tiêu đề trang dài ${title.length} ký tự` : "Không tìm thấy tiêu đề trang",
      "Tiêu đề là tên trang hiển thị trên tab trình duyệt và kết quả tìm kiếm.", false, { motPhan: Boolean(title) && (title.length < 30 || title.length > 60) }),
    makeCheck(group1, "Mô tả trang", 6, !description ? 0 : description.length >= 70 && description.length <= 160 ? 6 : 3,
      description ? `Mô tả trang dài ${description.length} ký tự` : "Không tìm thấy mô tả trang",
      "Mô tả tóm tắt nội dung trang trong kết quả tìm kiếm.", false, { motPhan: Boolean(description) && (description.length < 70 || description.length > 160) }),
    makeCheck(group1, "Thẻ H1", 6, h1.length === 1 ? 6 : h1.length > 1 ? 3 : 0,
      `Trang có ${h1.length} thẻ H1`, "H1 là tiêu đề chính của phần nội dung trang.", h1.length > 0, { motPhan: h1.length > 1 }),
    makeCheck(group1, "Thẻ H2", 3, h2.length >= 2 ? 3 : h2.length === 1 ? 2 : 0,
      `Trang có ${h2.length} thẻ H2`, "H2 chia nội dung thành các phần nhỏ hơn.", h2.length > 0, { motPhan: h2.length === 1 }),
    makeCheck(group1, "Chữ thay thế ảnh (alt)", 4,
      images.length === 0 ? 0 : imagesWithAlt / images.length >= 0.9 ? 4 : imagesWithAlt / images.length >= 0.5 ? 2 : 0,
      images.length ? `${imagesWithAlt} trong ${images.length} ảnh có chữ thay thế alt` : "Trang không có ảnh",
      "Chữ thay thế mô tả ảnh khi ảnh không hiển thị hoặc khi trình đọc màn hình đọc trang.",
      visibleImages.length > 0, { khongApDung: images.length === 0, motPhan: images.length > 0 && imagesWithAlt / images.length >= 0.5 && imagesWithAlt / images.length < 0.9 }),
    makeCheck(group1, "Độ dài nội dung", 4, words >= 300 ? 4 : words >= 150 ? 2 : 0,
      `Phần chữ hiển thị có ${words} từ`, "Số từ thể hiện lượng nội dung chữ có trong trang.", words > 0, { motPhan: words >= 150 && words < 300 }),
    makeCheck(group2, "HTTPS", 6, page.finalUrl.startsWith("https:") ? 6 : 0,
      page.isLocalhost ? "Website đang chạy trên localhost" : `Địa chỉ cuối dùng ${page.finalUrl.startsWith("https:") ? "HTTPS" : "HTTP"}`,
      "HTTPS mã hóa kết nối giữa trình duyệt và website.", false, { khongApDung: page.isLocalhost }),
    makeCheck(group2, "Địa chỉ chuẩn (canonical)", 4,
      tags(html, "link").some(tag => attributes(tag).rel?.toLowerCase().split(/\s+/).includes("canonical")) ? 4 : 0,
      tags(html, "link").some(tag => attributes(tag).rel?.toLowerCase().split(/\s+/).includes("canonical")) ? "Trang có thẻ canonical" : "Không tìm thấy thẻ canonical",
      "Canonical đánh dấu địa chỉ đại diện của trang.", false),
    makeCheck(group2, "robots.txt", 3, page.robotsTxtLoaded ? 3 : 0,
      page.robotsTxtLoaded ? "Tải được robots.txt" : "Không tải được robots.txt",
      "robots.txt công bố quy tắc thu thập dữ liệu của công cụ tìm kiếm.", false),
    makeCheck(group2, "sitemap.xml", 4, page.sitemapXmlLoaded ? 4 : 0,
      page.sitemapXmlLoaded ? "Tải được sitemap có danh sách địa chỉ trang" : "Không tải được sitemap hợp lệ",
      "Sitemap liệt kê địa chỉ trang để công cụ tìm kiếm nhận biết.", false),
    makeCheck(group2, "Ngôn ngữ trang", 2,
      Boolean(attributes(tags(html, "html")[0] || "").lang) ? 2 : 0,
      attributes(tags(html, "html")[0] || "").lang ? `Trang khai báo ngôn ngữ ${attributes(tags(html, "html")[0] || "").lang}` : "Trang chưa khai báo ngôn ngữ",
      "Khai báo lang cho biết ngôn ngữ chính của nội dung.", false),
    makeCheck(group2, "Dữ liệu có cấu trúc (JSON-LD)", 4, jsonLdValid ? 4 : jsonLd.length ? 1 : 0,
      jsonLdValid ? `Có ${jsonLd.length} khối JSON-LD hợp lệ` : jsonLd.length ? `Có ${jsonLd.length} khối JSON-LD nhưng nội dung không đọc được` : "Không tìm thấy JSON-LD",
      "JSON-LD là dữ liệu có cấu trúc giúp máy đọc một số thông tin về trang.", false, { motPhan: jsonLd.length > 0 && !jsonLdValid }),
    makeCheck(group2, "Không chặn Google", 2, noindex ? 0 : 2,
      noindex ? "Có thẻ noindex trong trang" : "Không tìm thấy thẻ noindex",
      "noindex là chỉ dẫn yêu cầu công cụ tìm kiếm không đưa trang vào kết quả.", false),
    makeCheck(group3, "Khung nhìn điện thoại", 5, viewport ? 5 : 0,
      viewport ? "Khung nhìn có width=device-width" : "Không tìm thấy width=device-width trong viewport",
      "Viewport giúp trang nhận biết chiều rộng màn hình thiết bị.", false),
    makeCheck(group3, "Dung lượng HTML", 3, page.bytes <= 200_000 ? 3 : page.bytes <= 500_000 ? 2 : 0,
      `HTML có dung lượng ${page.bytes} byte`,
      "Dung lượng HTML là kích thước dữ liệu mã trang đã tải.", false, { motPhan: page.bytes > 200_000 && page.bytes <= 500_000 }),
    makeCheck(group3, "Thời gian phản hồi", 4, page.durationMs <= 800 ? 4 : page.durationMs <= 1800 ? 2 : 0,
      `Website phản hồi trong ${page.durationMs} ms`,
      "Thời gian phản hồi là khoảng chờ đến khi máy chủ trả lời yêu cầu trang.", false, { motPhan: page.durationMs > 800 && page.durationMs <= 1800 }),
    makeCheck(group3, "Nén dữ liệu", 3, /^(gzip|br)$/i.test(page.contentEncoding) ? 3 : 0,
      page.contentEncoding ? `Máy chủ khai báo nén ${page.contentEncoding}` : "Không ghi nhận nén gzip hoặc br",
      "Nén dữ liệu làm giảm kích thước nội dung truyền qua mạng.", false, { khongApDung: page.isLocalhost }),
    makeCheck(group4, "Tiêu đề chia sẻ (og:title)", 3, metaContent(html, "og:title", "property") ? 3 : 0,
      metaContent(html, "og:title", "property") ? "Có thẻ og:title" : "Không tìm thấy thẻ og:title",
      "og:title là tiêu đề hiển thị khi chia sẻ trang trên mạng xã hội.", false),
    makeCheck(group4, "Ảnh chia sẻ (og:image)", 4,
      metaContent(html, "og:image", "property") && page.ogImageOk ? 4 : 0,
      !metaContent(html, "og:image", "property") ? "Không tìm thấy thẻ og:image" : page.ogImageOk ? "Ảnh og:image phản hồi mã 200" : "Ảnh og:image không phản hồi mã 200",
      "og:image là ảnh đại diện trang khi chia sẻ trên mạng xã hội.", Boolean(metaContent(html, "og:image", "property"))),
    makeCheck(group4, "Mô tả chia sẻ (og:description)", 3,
      metaContent(html, "og:description", "property") ? 3 : 0,
      metaContent(html, "og:description", "property") ? "Có thẻ og:description" : "Không tìm thấy thẻ og:description",
      "og:description là phần mô tả trang khi chia sẻ trên mạng xã hội.", false),
    makeCheck(group5, "Nút hành động", 5, hasCta ? 5 : 0,
      hasCta ? "Có nút hoặc liên kết với chữ kêu gọi hành động" : "Không tìm thấy chữ kêu gọi hành động trong nút hoặc liên kết",
      "Nút hành động là liên kết hoặc nút hiển thị lời kêu gọi khách liên hệ hoặc sử dụng dịch vụ.", hasCta),
    makeCheck(group5, "Thông tin liên hệ", 6, contactCount >= 2 ? 6 : contactCount === 1 ? 3 : 0,
      `Tìm thấy ${contactCount} trong 3 loại thông tin liên hệ`,
      "Các loại được đếm là số điện thoại Việt Nam, email và dấu hiệu địa chỉ.", contactCount > 0, { motPhan: contactCount === 1 }),
    makeCheck(group5, "Liên kết gọi điện", 3, telephoneLink ? 3 : 0,
      telephoneLink ? "Có liên kết tel: để gọi điện" : "Không tìm thấy liên kết tel:",
      "Liên kết tel: mở chức năng gọi điện trên thiết bị phù hợp.", telephoneLink),
    makeCheck(group5, "Biểu tượng tab (favicon)", 2, favicon ? 2 : 0,
      favicon ? "Trang có liên kết biểu tượng tab" : "Không tìm thấy liên kết biểu tượng tab",
      "Favicon là biểu tượng nhỏ hiển thị cạnh tên trang trên tab trình duyệt.", false),
    makeCheck(group5, "Điều hướng", 4, nav ? 4 : 0,
      nav ? "Tìm thấy thẻ nav hoặc ít nhất 3 liên kết trong header" : "Không tìm thấy nav hoặc ít nhất 3 liên kết trong header",
      "Điều hướng là nhóm liên kết chuyển đến các phần hoặc trang khác.", nav)
  ];
}

export function scorePage(page: PageData): Audit {
  const checks = getChecks(page);
  const findings = checks.map((check, index): Criterion => {
    const trangThai: CriterionStatus = check.khongApDung ? "khong_ap_dung"
      : check.diemDat === check.diemToiDa ? "dat"
      : check.motPhan ? "mot_phan"
      : "chua_dat";
    return {
      id: index + 1,
      ...check,
      trangThai,
      name: check.ten,
      status: check.diemDat > 0 ? "tốt" : "chú ý",
      meaning: check.yNghia,
      points: check.diemDat
    };
  });
  const applicable = findings.filter(item => item.trangThai !== "khong_ap_dung");
  const maxScore = applicable.reduce((sum, item) => sum + item.diemToiDa, 0);
  const score = maxScore ? Math.round(applicable.reduce((sum, item) => sum + item.diemDat, 0) / maxScore * 100) : 0;
  const groupScores = GROUPS.map(group => {
    const items = findings.filter(item => item.nhom === group.nhom && item.trangThai !== "khong_ap_dung");
    const available = items.reduce((sum, item) => sum + item.diemToiDa, 0);
    const earned = items.reduce((sum, item) => sum + item.diemDat, 0);
    return { nhom: group.nhom, diem: available ? Math.round(earned / available * group.diemToiDa) : 0, diemToiDa: group.diemToiDa };
  });
  const html = page.html;
  const wordCount = countWords(visibleText(html));
  const rootDivEmpty = /<div\b[^>]*(?:id|class)=["'](?:root|app)["'][^>]*>\s*<\/div\s*>/i.test(html);
  const canhBaoJS = wordCount < 100 && (tags(html, "script").length >= 5 || rootDivEmpty);
  const title = contentOf(html, "title")[0] || "";
  return {
    score,
    findings,
    title,
    groupScores,
    canhBaoJS,
    giaiThichJS: canhBaoJS
      ? `Trang có ${wordCount} từ hiển thị và dấu hiệu nội dung được tạo bằng JavaScript; phần chữ có thể chưa hiện trong HTML tải về.`
      : `Trang có ${wordCount} từ hiển thị trong HTML tải về.`
  };
}

export function kiemTraTuKhoaChinh(html: string, tuKhoa: string): "có" | "không có" {
  const keyword = tuKhoa.trim().toLocaleLowerCase("vi");
  if (!keyword) return "không có";
  const title = contentOf(html, "title")[0] || "";
  const headings = contentOf(html, "h1").join(" ");
  const description = metaContent(html, "description");
  return [title, headings, description].some(value => value.toLocaleLowerCase("vi").includes(keyword)) ? "có" : "không có";
}
