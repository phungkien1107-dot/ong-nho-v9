import { lookup } from "node:dns/promises";
import { isIP } from "node:net";

export type PageData = {
  url: string;
  finalUrl: string;
  html: string;
  status: number;
  contentEncoding: string;
  durationMs: number;
  bytes: number;
  isLocalhost: boolean;
  robotsTxtLoaded: boolean;
  sitemapXmlLoaded: boolean;
  ogImageOk: boolean;
};

const MAX_BYTES = 2 * 1024 * 1024;
const TIMEOUT_MS = 15_000;
const USER_AGENT =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";

function isPrivateIp(ip: string): boolean {
  const value = ip.toLowerCase().split("%")[0];
  if (value === "::1" || value === "::" || value.startsWith("fc") || value.startsWith("fd") || /^fe[89ab]/.test(value)) return true;
  if (value.startsWith("::ffff:")) return isPrivateIp(value.slice(7));
  const parts = value.split(".").map(Number);
  if (parts.length !== 4 || parts.some(Number.isNaN)) return false;
  return parts[0] === 10 || parts[0] === 127 || parts[0] === 0 ||
    (parts[0] === 169 && parts[1] === 254) || (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) ||
    (parts[0] === 192 && parts[1] === 168) || (parts[0] === 100 && parts[1] >= 64 && parts[1] <= 127);
}

function isLoopback(host: string): boolean {
  return host === "localhost" || host.endsWith(".localhost") || host === "127.0.0.1" || host === "::1";
}

function normalizeUrl(input: string): URL {
  const value = /^[a-z][a-z\d+.-]*:\/\//i.test(input) ? input : `https://${input}`;
  try {
    const url = new URL(value);
    if (!["http:", "https:"].includes(url.protocol) || url.username || url.password) throw new Error();
    url.hash = "";
    return url;
  } catch {
    throw new Error("Địa chỉ website không hợp lệ. Nhập tên miền hoặc địa chỉ HTTP/HTTPS.");
  }
}

export async function validatePublicUrl(input: string): Promise<URL> {
  const url = normalizeUrl(input);
  await validateHost(url, true);
  return url;
}

async function validateHost(url: URL, allowLoopback = false): Promise<void> {
  const host = url.hostname.replace(/^\[|\]$/g, "").toLowerCase();
  if (isLoopback(host) && allowLoopback) return;
  if (host.endsWith(".local") || host.endsWith(".internal")) throw new Error("Không thể tải website nội bộ.");
  if (isIP(host)) {
    if (isPrivateIp(host)) throw new Error("Không thể tải địa chỉ mạng nội bộ.");
    return;
  }
  let records;
  try {
    records = await lookup(host, { all: true, verbatim: true });
  } catch {
    throw new Error("Không tìm thấy website. Kiểm tra địa chỉ và kết nối mạng.");
  }
  if (!records.length || records.some(record => isPrivateIp(record.address))) throw new Error("Không thể tải địa chỉ mạng nội bộ.");
}

async function request(
  input: URL,
  signal: AbortSignal,
  method: "GET" | "HEAD" = "GET",
  redirects = 0,
  allowLoopback = false
): Promise<{ response: Response; url: URL }> {
  await validateHost(input, allowLoopback);
  let response: Response;
  try {
    response = await fetch(input, {
      method,
      redirect: "manual",
      signal,
      headers: { "user-agent": USER_AGENT, accept: "text/html,application/xhtml+xml,*/*;q=0.8" }
    });
  } catch (error) {
    if (signal.aborted) throw error;
    throw new Error("Không kết nối được website. Kiểm tra địa chỉ hoặc tình trạng mạng.");
  }
  if ([301, 302, 303, 307, 308].includes(response.status)) {
    const location = response.headers.get("location");
    await response.body?.cancel();
    if (!location || redirects >= 5) throw new Error("Website chuyển hướng quá nhiều lần.");
    return request(normalizeUrl(new URL(location, input).toString()), signal, method, redirects + 1, allowLoopback);
  }
  return { response, url: input };
}

async function readLimited(response: Response): Promise<Uint8Array> {
  if (!response.body) return new Uint8Array();
  const reader = response.body.getReader();
  const chunks: Uint8Array[] = [];
  let size = 0;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    size += value.byteLength;
    if (size > MAX_BYTES) {
      await reader.cancel();
      throw new Error("Trang vượt quá giới hạn dung lượng 2 MB.");
    }
    chunks.push(value);
  }
  const bytes = new Uint8Array(size);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return bytes;
}

async function resourceOk(url: URL, signal: AbortSignal, allowLoopback: boolean, sitemap = false): Promise<boolean> {
  try {
    const { response } = await request(url, signal, "GET", 0, allowLoopback);
    if (response.status !== 200) {
      await response.body?.cancel();
      return false;
    }
    const bytes = await readLimited(response);
    const body = new TextDecoder().decode(bytes);
    return sitemap ? /<(?:urlset|sitemapindex)\b/i.test(body) : true;
  } catch (error) {
    if (signal.aborted) throw error;
    return false;
  }
}

async function imageOpens(url: URL, signal: AbortSignal, allowLoopback: boolean): Promise<boolean> {
  try {
    const head = await request(url, signal, "HEAD", 0, allowLoopback);
    if (head.response.status === 200) return true;
    await head.response.body?.cancel();
    const get = await request(url, signal, "GET", 0, allowLoopback);
    if (get.response.status === 200) {
      await get.response.body?.cancel();
      return true;
    }
    await get.response.body?.cancel();
    return false;
  } catch (error) {
    if (signal.aborted) throw error;
    return false;
  }
}

export async function fetchPage(input: string): Promise<PageData> {
  const initialUrl = normalizeUrl(input.trim());
  const isLocalhost = isLoopback(initialUrl.hostname.replace(/^\[|\]$/g, "").toLowerCase());
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  const started = Date.now();
  try {
    const { response, url: finalUrl } = await request(initialUrl, controller.signal, "GET", 0, isLocalhost);
    const durationMs = Date.now() - started;
    const contentType = response.headers.get("content-type") || "";
    if (contentType && !/text\/html|application\/xhtml\+xml/i.test(contentType)) {
      await response.body?.cancel();
      throw new Error("Địa chỉ này không trả về trang HTML.");
    }
    const bytes = await readLimited(response);
    const html = new TextDecoder().decode(bytes);
    const sitemapTxt = /<loc>\s*([^<]*sitemap[^<]*)<\/loc>/i.exec(html)?.[1]?.trim();
    const sitemapUrl = sitemapTxt ? new URL(sitemapTxt, finalUrl) : new URL("/sitemap.xml", finalUrl);
    const ogImageValue = /<meta\b(?=[^>]*(?:property|name)=["']og:image["'])[^>]*content=["']([^"']+)["']/i.exec(html)?.[1]
      || /<meta\b(?=[^>]*content=["']([^"']+)["'])[^>]*(?:property|name)=["']og:image["']/i.exec(html)?.[1];
    const imagePromise = (async () => {
      if (!ogImageValue) return false;
      try {
        return await imageOpens(new URL(ogImageValue.replace(/&amp;/g, "&"), finalUrl), controller.signal, isLocalhost);
      } catch (error) {
        if (controller.signal.aborted) throw error;
        return false;
      }
    })();
    const [robotsTxtLoaded, sitemapXmlLoaded, ogImageOk] = await Promise.all([
      resourceOk(new URL("/robots.txt", finalUrl), controller.signal, isLocalhost),
      resourceOk(sitemapUrl, controller.signal, isLocalhost, true),
      imagePromise
    ]);
    return {
      url: initialUrl.toString(),
      finalUrl: finalUrl.toString(),
      html,
      status: response.status,
      contentEncoding: response.headers.get("content-encoding") || "",
      durationMs,
      bytes: bytes.byteLength,
      isLocalhost,
      robotsTxtLoaded,
      sitemapXmlLoaded,
      ogImageOk
    };
  } catch (error) {
    if (controller.signal.aborted) throw new Error("Website phản hồi quá thời gian 15 giây.");
    if (error instanceof Error) throw error;
    throw new Error("Không tải được website do lỗi mạng.");
  } finally {
    clearTimeout(timer);
  }
}
