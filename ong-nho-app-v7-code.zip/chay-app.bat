@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Chua tim thay Node.js. Cai Node.js 20 tro len roi chay lai tep nay.
  pause
  exit /b 1
)
where npm >nul 2>nul
if errorlevel 1 (
  echo Chua tim thay npm. Cai Node.js 20 tro len roi chay lai tep nay.
  pause
  exit /b 1
)
if not exist ".env" copy ".env.example" ".env" >nul
if not exist "node_modules" (
  echo Dang cai cac goi can thiet cho lan chay dau...
  call npm install
  if errorlevel 1 (
    echo Khong cai duoc cac goi. Kiem tra ket noi internet roi chay lai.
    pause
    exit /b 1
  )
)
start "Ong Nho" /min cmd /c "cd /d ""%~dp0"" && npm run dev"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ready = $false; for ($i = 0; $i -lt 40; $i++) { try { $r = Invoke-WebRequest -UseBasicParsing 'http://127.0.0.1:3000/api/health' -TimeoutSec 1; if ($r.StatusCode -eq 200) { $ready = $true; break } } catch {}; Start-Sleep -Milliseconds 500 }; if ($ready) { Start-Process 'http://localhost:3000'; exit 0 } else { exit 1 }"
if errorlevel 1 (
  echo Ung dung chua khoi dong duoc. Kiem tra cua so Ong Nho va thu lai.
  pause
  exit /b 1
)
