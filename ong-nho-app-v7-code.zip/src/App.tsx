import { useState } from "react";
import Bee from "./ui/Bee";
import Check from "./tabs/Check";
import Compare from "./tabs/Compare";
import History from "./tabs/History";
import Stats from "./tabs/Stats";

const tabs = [
  { id: "check", label: "Kiểm tra", icon: <><path d="M9 3h6l1 2h4v16H4V5h4l1-2Z" /><path d="m8 13 2.5 2.5L16 10" /></> },
  { id: "compare", label: "So sánh", icon: <><path d="M8 4H4v16h4" /><path d="M16 4h4v16h-4" /><path d="M8 12h8" /><path d="m12 8 4 4-4 4" /></> },
  { id: "history", label: "Lịch sử", icon: <><path d="M3 12a9 9 0 1 0 2.6-6.4L3 8" /><path d="M3 3v5h5" /><path d="M12 7v5l3 2" /></> },
  { id: "stats", label: "Thống kê", icon: <><path d="M4 19V5" /><path d="M4 19h17" /><path d="m7 15 4-4 3 2 5-6" /><path d="M16 7h3v3" /></> }
] as const;
type Tab = typeof tabs[number]["id"];

export default function App() {
  const [active, setActive] = useState<Tab>("check");
  const [soundEnabled, setSoundEnabled] = useState(true);
  const teamName = import.meta.env.VITE_NHOM_TEN;
  const teamEmail = import.meta.env.VITE_NHOM_EMAIL;
  const teamPhone = import.meta.env.VITE_NHOM_DIEN_THOAI;

  return <div className="app-shell">
    <header className="topbar">
      <a className="brand" href="#" onClick={event => { event.preventDefault(); setActive("check"); }}>
        <Bee /><span><b>Ong Nhỏ</b><small>Kiểm tra website</small></span>
      </a>
      <nav aria-label="Các mục chính">{tabs.map(tab =>
        <button key={tab.id} type="button" className={`nav-button ${active === tab.id ? "active" : ""}`} aria-current={active === tab.id ? "page" : undefined} onClick={() => setActive(tab.id)}>
          <svg className="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{tab.icon}</svg>
          <span>{tab.label}</span>
        </button>
      )}</nav>
      {active === "check" && <button className="nav-button sound-button" type="button" aria-label={`Âm báo ${soundEnabled ? "đang bật" : "đang tắt"}`} aria-pressed={soundEnabled} onClick={() => setSoundEnabled(value => !value)}>
        <svg className="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
          <path d="M11 5 6 9H3v6h3l5 4V5Z" />
          {soundEnabled ? <><path d="M15.5 8.5a5 5 0 0 1 0 7" /><path d="M18.5 5.5a9 9 0 0 1 0 13" /></> : <path d="m16 9 5 6m0-6-5 6" />}
        </svg><span className="sound-label">Âm báo: {soundEnabled ? "bật" : "tắt"}</span>
      </button>}
      <span className="local-badge"><i />Lưu trên máy bạn</span>
    </header>
    <main>
      {active === "check" && <section className="welcome">
        <div><p className="eyebrow">BẢNG KIỂM TRA WEBSITE</p><h1>Tình trạng website, trong một lượt nhìn.</h1>
          <p>Điểm tổng thể và 25 tiêu chí về nội dung, hiển thị và phản hồi.</p></div>
        <Bee />
      </section>}
      <section className="tab-content" key={active} aria-label={tabs.find(tab => tab.id === active)?.label}>
        {active === "check" && <Check soundEnabled={soundEnabled} />}
        {active === "compare" && <Compare />}
        {active === "history" && <History />}
        {active === "stats" && <Stats />}
      </section>
    </main>
    <footer>Ong Nhỏ <span>·</span> Lịch sử chỉ lưu trong trình duyệt của bạn
      {(teamName || teamEmail || teamPhone) && <span className="team-contact">
        {teamName && <> · {teamName}</>}
        {teamEmail && <> · <a href={`mailto:${teamEmail}`}>{teamEmail}</a></>}
        {teamPhone && <> · <a href={`tel:${teamPhone}`}>{teamPhone}</a></>}
      </span>}
    </footer>
  </div>;
}
