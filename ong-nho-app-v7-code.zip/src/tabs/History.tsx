import { useEffect, useMemo, useState } from "react";
import { clearChecks, deleteSiteHistory, getChecks, type SavedCheck } from "../lib/history";
import Bee from "../ui/Bee";
import Gauge from "../ui/Gauge";
import Shot from "../ui/Shot";

export default function History() {
  const [rows, setRows] = useState<SavedCheck[]>([]);
  const [selected, setSelected] = useState<SavedCheck | null>(null);
  const [expanded, setExpanded] = useState("");
  const [loading, setLoading] = useState(true);

  async function refresh() {
    setLoading(true);
    try { setRows(await getChecks()); }
    finally { setLoading(false); }
  }
  useEffect(() => { void refresh(); }, []);

  const groups = useMemo(() => {
    const result = new Map<string, SavedCheck[]>();
    for (const row of rows) result.set(row.siteKey, [...(result.get(row.siteKey) || []), row]);
    return [...result.entries()];
  }, [rows]);

  async function removeSite(key: string) {
    await deleteSiteHistory(key);
    if (selected?.siteKey === key) setSelected(null);
    await refresh();
  }
  async function clearAll() {
    await clearChecks();
    setRows([]);
    setSelected(null);
  }

  return <div className="stack">
    <div className="section-title"><div><p className="eyebrow">LƯU RIÊNG TRÊN TRÌNH DUYỆT NÀY</p><h2>Lịch sử kiểm tra</h2></div>
      {rows.length > 0 && <button className="button secondary" type="button" onClick={clearAll}>Xóa tất cả</button>}</div>
    {loading && <section className="panel loading-panel" role="status" aria-live="polite" aria-busy="true">
      <span className="bee-flight"><Bee small /></span><div><p className="eyebrow">ĐANG MỞ LỊCH SỬ</p><strong>Đợi một chút nhé…</strong><div className="progress-track"><span /></div></div>
    </section>}
    {!loading && !rows.length && <div className="empty panel"><Bee small /><h2>Lịch sử đang trống</h2><p>Kết quả sẽ lưu trên trình duyệt này sau khi bạn kiểm tra website.</p></div>}
    {groups.map(([key, checks]) => <section className="panel stack" key={key} style={{ gap: 12 }}>
      <div className="section-title">
        <div><p className="eyebrow">WEBSITE</p><h3>{checks[0].audit.page.finalUrl}</h3><span className="subtle">{checks.length} lần kiểm tra</span></div>
        <button className="button secondary" type="button" aria-label={`Xóa lịch sử ${checks[0].audit.page.finalUrl}`} onClick={() => removeSite(key)}>Xóa website</button>
      </div>
      {checks.map(row => <article className="history-item" key={row.id} style={{ borderTop: "1px solid #eee4d3", paddingTop: 12 }}>
        <Gauge value={row.audit.score} />
        <div className="history-info" style={{ flex: 1 }}>
          <time>{new Date(row.createdAt).toLocaleString("vi-VN")}</time>
          <h3>{row.audit.title || "Chưa có tiêu đề trang"}</h3>
          <p>{row.audit.score}/100 điểm · {row.audit.findings.filter(item => item.trangThai === "chua_dat" || item.trangThai === "mot_phan").length} tiêu chí chưa đạt đủ điểm</p>
        </div>
        <button className="button secondary" type="button" onClick={() => setSelected(row)}>Xem kết quả</button>
        <button className="nav-button" type="button" aria-expanded={expanded === row.id} aria-label={`${expanded === row.id ? "Ẩn" : "Xem"} chi tiết ${row.audit.page.finalUrl}`} onClick={() => setExpanded(expanded === row.id ? "" : row.id)}>
          {expanded === row.id ? "Ẩn" : "Chi tiết"}
        </button>
        {expanded === row.id && <div style={{ flexBasis: "100%" }}>
          {row.audit.anh
            ? <Shot anh={row.audit.anh} rects={row.audit.rects} ghiChu={auditNotes(row.audit, row.audit.rects)} />
            : <p className="subtle">Ảnh lần này không có trong lịch sử; điểm và nhận xét vẫn được lưu.</p>}
          <p>{row.audit.nhanXet.diemManh.join(" · ")}</p>
        </div>}
      </article>)}
    </section>)}
    {selected && <section className="panel stack" aria-label="Kết quả đã chọn">
      <div className="section-title"><div><p className="eyebrow">KẾT QUẢ ĐÃ LƯU</p><h2>{selected.audit.title || selected.audit.page.finalUrl}</h2><p className="subtle">{new Date(selected.createdAt).toLocaleString("vi-VN")}</p></div>
        <button className="button secondary" type="button" onClick={() => setSelected(null)}>Đóng</button></div>
      <div className="result-head"><Gauge value={selected.audit.score} /><div><b>{selected.audit.score}/100 điểm</b>
        {selected.audit.groupScores.map(group => <p key={group.nhom}>{group.nhom}: {group.diem}/{group.diemToiDa}</p>)}</div></div>
      {selected.audit.anh && <Shot anh={selected.audit.anh} rects={selected.audit.rects} ghiChu={auditNotes(selected.audit, selected.audit.rects)} />}
      {selected.audit.loiChinhTa.length > 0 && <section className="panel">
        <h3>Ảnh lỗi chính tả</h3>
        {selected.audit.loiChinhTa.map((issue, index) => {
          const image = selected.audit.anhChinhTa?.find(item => item.tuSai === issue.tuSai);
          return <div key={`${issue.tuSai}-${index}`}><p><b>{index + 1}. {issue.tuSai}</b> · {issue.cauChuaTu}</p>
            {image ? <Shot anh={image.anh} rects={[image.rect]} tone="bad" startNumber={index + 1}
              ghiChu={[{ id: index + 1, ten: issue.tuSai, tinhTrang: issue.cauChuaTu, tone: "bad" }]} /> : <p className="subtle">Ảnh đánh dấu lỗi này chưa có.</p>}
          </div>;
        })}
      </section>}
      <div className="findings">{selected.audit.findings.map(item => <article className="finding" key={item.id}>
        <div style={{ minWidth: 0 }}><h3>{item.ten} · {item.diemDat}/{item.diemToiDa}</h3><p>{item.tinhTrang}</p><p>{item.yNghia}</p>
          <HistoryFindingShot item={item} audit={selected.audit} />
        </div>
      </article>)}</div>
      <div className="review-grid" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(220px,1fr))", gap: 16 }}>
        {[true, false].map(strong => {
          const lines = strong ? selected.audit.nhanXet.diemManh : selected.audit.nhanXet.diemYeu;
          const links = selected.audit.nhanXet.tieuChiLienQuan?.[strong ? "diemManh" : "diemYeu"] || [];
          const ranked = selected.audit.findings.filter(item => item.trangThai !== "khong_ap_dung").sort((a, b) => strong
            ? b.diemDat / Math.max(1, b.diemToiDa) - a.diemDat / Math.max(1, a.diemToiDa)
            : a.diemDat / Math.max(1, a.diemToiDa) - b.diemDat / Math.max(1, b.diemToiDa));
          return <div key={String(strong)}><h3>{strong ? "3 điểm mạnh" : "3 điểm còn yếu"}</h3>
            {lines.map((line, index) => {
              const related = (links[index] || []).map(id => selected.audit.findings.find(finding => finding.id === id))
                .filter((item): item is SavedCheck["audit"]["findings"][number] => Boolean(item));
              const items = related.length ? related : ranked[index] ? [ranked[index]] : [];
              return <div key={index}><p>{line}</p>{items.map(item => <HistoryFindingShot key={item.id} item={item} audit={selected.audit} />)}</div>;
            })}
          </div>;
        })}
      </div>
    </section>}
  </div>;
}

function HistoryFindingShot({ item, audit }: { item: SavedCheck["audit"]["findings"][number]; audit: SavedCheck["audit"] }) {
  if (item.trangThai === "khong_ap_dung") return null;
  const tone: "good" | "partial" | "bad" = item.trangThai === "dat" ? "good" : item.trangThai === "mot_phan" ? "partial" : "bad";
  const note = (rects: SavedCheck["audit"]["rects"]): Array<{ id: number; ten: string; tinhTrang: string; tone: "good" | "partial" | "bad" }> =>
    rects.map((mark, index) => ({
      id: index + 1,
      ten: item.ten,
      tinhTrang: `${item.tinhTrang}${mark.approximate ? " · chưa xác định chính xác vị trí." : ""}`,
      tone
    }));
  const extra = audit.anhPhu?.find(image => image.id === item.id);
  if (extra) return <Shot anh={extra.anh} rects={extra.rects} tone={tone} ghiChu={note(extra.rects)} />;
  const rect = item.rect ? Array.isArray(item.rect) ? item.rect : [item.rect]
    : audit.rects.filter(mark => mark.id === ({ 3: "h1", 5: "anh_alt", 21: "cta", 25: "dieu_huong" } as Record<number, string>)[item.id]);
  return rect.length && audit.anh
    ? <Shot anh={audit.anh} rects={rect} tone={tone} ghiChu={note(rect)} />
    : <p className="subtle">{item.tinhTrang} · nằm bên dưới màn hình đầu hoặc không tìm thấy</p>;
}

function auditNotes(audit: SavedCheck["audit"], rects: SavedCheck["audit"]["rects"]): Array<{ id: number; ten: string; tinhTrang: string; tone: "good" | "partial" | "bad" }> {
  const ids: Record<string, number> = { h1: 3, anh_alt: 5, cta: 21, dieu_huong: 25 };
  return rects.map((rect, index) => {
    const finding = audit.findings.find(item => item.id === ids[rect.id]);
    const tone: "good" | "partial" | "bad" = finding?.trangThai === "dat" ? "good" : finding?.trangThai === "chua_dat" ? "bad" : "partial";
    return {
      id: index + 1,
      ten: finding?.ten || rect.id,
      tinhTrang: `${finding?.tinhTrang || "Vùng được khoanh trong ảnh."}${rect.approximate ? " · chưa xác định chính xác vị trí." : ""}`,
      tone
    };
  });
}
