import { useEffect, useMemo, useState, type FormEvent } from "react";
import type { AuditResult, Finding, Rect } from "../api";
import { saveCheck } from "../lib/history";
import Bee from "../ui/Bee";
import Gauge from "../ui/Gauge";
import Shot from "../ui/Shot";

type SiteResult = { url: string; domain: string; audit?: AuditResult; error?: string };
type CompareResponse = { sites: SiteResult[]; ketLuan: string[]; loiAI: string };
type Difference = {
  id: number;
  nhom: string;
  ten: string;
  khach: Finding;
  doiThu: Finding;
  doiThuTen: string;
  chenhlech: number;
};

const stages = ["Đang mở và chấm điểm website…", "Đang chuẩn bị ảnh…", "Đang đối chiếu kết quả…"];

function comparableSites(sites: SiteResult[]): SiteResult[] {
  return sites.filter(site => site.audit);
}

function differences(sites: SiteResult[], mode: "loss" | "win"): Difference[] {
  const valid = comparableSites(sites);
  const customer = valid[0]?.audit;
  const competitors = valid.slice(1);
  if (!customer || !competitors.length) return [];
  return customer.findings.flatMap(finding => {
    const compared = competitors.flatMap(site => {
      const rivalFinding = site.audit?.findings.find(item => item.id === finding.id);
      return rivalFinding && site.audit ? [{ finding: rivalFinding, domain: site.domain }] : [];
    });
    if (!compared.length) return [];
    const rival = compared.reduce((selected, item) => mode === "loss"
      ? item.finding.diemDat > selected.finding.diemDat ? item : selected
      : item.finding.diemDat < selected.finding.diemDat ? item : selected);
    const delta = mode === "loss" ? rival.finding.diemDat - finding.diemDat : finding.diemDat - rival.finding.diemDat;
    return delta > 0 ? [{
      id: finding.id,
      nhom: finding.nhom,
      ten: finding.ten,
      khach: finding,
      doiThu: rival.finding,
      doiThuTen: rival.domain,
      chenhlech: delta
    }] : [];
  });
}

function Crown() {
  return <svg aria-label="Điểm cao nhất" role="img" width="32" height="28" viewBox="0 0 32 28">
    <path d="M3 23h26l-2-14-7 6-4-11-5 11-7-6z" fill="#FFB400" stroke="#2B1B0E" strokeWidth="1.5" strokeLinejoin="round" />
    <path d="M5 25h22" stroke="#2B1B0E" strokeWidth="2" strokeLinecap="round" />
    <circle cx="4" cy="8" r="2" fill="#FFB400" stroke="#2B1B0E" />
    <circle cx="16" cy="3" r="2" fill="#FFB400" stroke="#2B1B0E" />
    <circle cx="28" cy="8" r="2" fill="#FFB400" stroke="#2B1B0E" />
  </svg>;
}

function markedRects(finding?: Finding): Rect[] {
  if (!finding || finding.trangThai === "khong_ap_dung" || !("rect" in finding) || !finding.rect) return [];
  return Array.isArray(finding.rect) ? finding.rect : [finding.rect];
}

function annotationTone(finding: Finding): "good" | "partial" | "bad" {
  return finding.trangThai === "dat" ? "good" : finding.trangThai === "chua_dat" ? "bad" : "partial";
}

function scoreText(finding?: Finding): string {
  if (!finding) return "Không có dữ liệu";
  return finding.trangThai === "khong_ap_dung"
    ? "Không áp dụng"
    : `${finding.diemDat} / ${finding.diemToiDa} điểm`;
}

export default function Compare() {
  const [customerUrl, setCustomerUrl] = useState("");
  const [competitorUrls, setCompetitorUrls] = useState([""]);
  const [comparison, setComparison] = useState<CompareResponse>();
  const [busy, setBusy] = useState(false);
  const [phase, setPhase] = useState(0);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!busy) return;
    setPhase(0);
    const timer = window.setInterval(() => setPhase(value => (value + 1) % stages.length), 1500);
    return () => window.clearInterval(timer);
  }, [busy]);

  const validSites = comparison ? comparableSites(comparison.sites) : [];
  const topScore = validSites.length ? Math.max(...validSites.map(site => site.audit?.score || 0)) : -1;
  const lost = useMemo(() => comparison ? differences(comparison.sites, "loss") : [], [comparison]);
  const won = useMemo(() => comparison ? differences(comparison.sites, "win") : [], [comparison]);

  function updateCompetitor(index: number, value: string) {
    setCompetitorUrls(current => current.map((url, position) => position === index ? value : url));
  }

  async function submit(event: FormEvent) {
    event.preventDefault();
    setError("");
    setComparison(undefined);
    setBusy(true);
    try {
      const response = await fetch("/api/compare", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ urlKhach: customerUrl.trim(), urlDoiThu: competitorUrls.map(url => url.trim()) })
      });
      const data = await response.json() as CompareResponse | { error?: string };
      if (!response.ok) throw new Error("error" in data ? data.error || "Không thể hoàn tất so sánh." : "Không thể hoàn tất so sánh.");
      const result = data as CompareResponse;
      setComparison(result);
      for (const site of result.sites) {
        if (site.audit) await saveCheck(site.audit);
      }
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Không thể hoàn tất so sánh.");
    } finally {
      setBusy(false);
    }
  }

  function renderDifference(item: Difference, showImages: boolean) {
    const customer = validSites[0];
    const rival = validSites.find(site => site.domain === item.doiThuTen);
    return <article key={item.id} className="difference-item" style={{ borderTop: "1px solid #eadfca", padding: "12px 0" }}>
      <h3 style={{ margin: "0 0 5px" }}>{item.ten} · {item.khach.diemDat}/{item.khach.diemToiDa} so với {item.doiThu.diemDat}/{item.doiThu.diemToiDa} điểm ({item.chenhlech} điểm)</h3>
      <p className="subtle" style={{ margin: 0 }}>{item.nhom} · {item.doiThuTen}</p>
      {showImages && <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,360px),1fr))", gap: 12, marginTop: 12 }}>
        {[{ label: "Website khách", site: customer, finding: item.khach }, { label: "Đối thủ", site: rival, finding: item.doiThu }].map(({ label, site, finding }) =>
          <div className="panel" key={label} style={{ padding: 12, minWidth: 0 }}>
            <h4 style={{ margin: "0 0 8px" }}>{label} · {site?.domain || "Website"}</h4>
            {site?.audit?.anh
              ? <Shot anh={site.audit.anhPhu?.find(image => image.id === item.id)?.anh || site.audit.anh}
                rects={site.audit.anhPhu?.find(image => image.id === item.id)?.rects || markedRects(finding)} tone={annotationTone(finding)}
                ghiChu={(site.audit.anhPhu?.find(image => image.id === item.id)?.rects || markedRects(finding)).map((rect, index) => ({
                  id: index + 1,
                  ten: item.ten,
                  tinhTrang: `${finding.tinhTrang}${rect.approximate ? " · chưa xác định chính xác vị trí." : ""}`,
                  tone: annotationTone(finding)
                }))} />
              : <p className="subtle">Ảnh chụp chưa khả dụng.</p>}
          </div>
        )}
      </div>}
    </article>;
  }

  return <div className="stack">
    <form className="panel stack" onSubmit={submit}>
      <div className="section-title"><div><p className="eyebrow">ĐỐI CHIẾU WEBSITE</p><h2>So sánh web</h2></div></div>
      <label className="field">Địa chỉ website khách
        <input type="text" inputMode="url" required placeholder="https://tenmien.vn" value={customerUrl} onChange={event => setCustomerUrl(event.target.value)} />
      </label>
      {competitorUrls.map((url, index) => <label className="field" key={index}>Địa chỉ website đối thủ {index + 1}
        <div style={{ display: "flex", gap: 8 }}>
          <input type="text" inputMode="url" required placeholder="https://tenmien.vn" value={url} onChange={event => updateCompetitor(index, event.target.value)} />
          {competitorUrls.length > 1 && <button className="button secondary" type="button" aria-label={`Bỏ website đối thủ ${index + 1}`} onClick={() => setCompetitorUrls(current => current.filter((_, position) => position !== index))}>Bỏ</button>}
        </div>
      </label>)}
      {competitorUrls.length < 3 && <button className="button secondary" type="button" onClick={() => setCompetitorUrls(current => [...current, ""])}>Thêm website đối thủ</button>}
      <button className="button" type="submit" disabled={busy}>{busy ? "Đang so sánh…" : "So sánh website"}</button>
    </form>

    {busy && <section className="panel loading-panel" role="status" aria-live="polite" aria-busy="true">
      <span className="bee-flight"><Bee small /></span><div><p className="eyebrow">ĐANG SO SÁNH</p><strong>{stages[phase]}</strong><div className="progress-track"><span /></div></div>
    </section>}
    {error && <p className="notice error" role="alert">{error} Bạn kiểm tra lại địa chỉ website rồi thử lại nhé.</p>}
    {!comparison && !busy && !error && <div className="empty panel"><Bee small /><h2>Sẵn sàng đối chiếu</h2><p>Nhập website khách và ít nhất một website đối thủ ở trên.</p></div>}
    {comparison && <>
      {comparison.loiAI && <p className="notice" role="status">{comparison.loiAI} Kết quả vẫn dựa trên điểm chấm; bạn có thể thử lại sau.</p>}
      <section className="compare-grid" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(min(100%,280px),1fr))", gap: 16 }}>
        {comparison.sites.map((site, index) => {
          const audit = site.audit;
          return <article className="panel compare-card stack" key={`${site.url}-${index}`} style={{ position: "relative", minWidth: 0 }}>
            {audit && audit.score === topScore && <span style={{ display: "flex", alignItems: "center", gap: 6, color: "#775300", fontWeight: 700 }}><Crown /> Điểm cao nhất</span>}
            <span className="eyebrow">{index === 0 ? "WEBSITE KHÁCH" : `ĐỐI THỦ ${index}`}</span>
            {audit
              ? <>
                <Gauge value={audit.score} />
                <h2 style={{ margin: 0 }}>{audit.title || "Chưa có tiêu đề trang"}</h2>
                <a href={audit.page.finalUrl} target="_blank" rel="noreferrer">{audit.page.finalUrl}</a>
                <div style={{ height: 10, borderRadius: 10, background: "#f0e5d1", overflow: "hidden" }} aria-label={`Điểm ${audit.score} trên 100`}>
                  <div style={{ width: `${audit.score}%`, height: "100%", background: "#FFB400" }} />
                </div>
                <strong>{audit.score}/100 điểm</strong>
                <div>{audit.groupScores.map(group => <p key={group.nhom} style={{ margin: "5px 0" }}>{group.nhom}: <b>{group.diem}/{group.diemToiDa}</b></p>)}</div>
              </>
              : <div className="notice error"><b>{site.domain}</b><p>{site.error || "Chưa tải được website này nên chưa có điểm."} Bạn thử kiểm tra địa chỉ hoặc mở lại trang nhé.</p></div>}
          </article>;
        })}
      </section>

      {validSites.length > 1
        ? <>
          <section className="panel stack">
            <div><p className="eyebrow">TỔNG HỢP 5 NHÓM</p><h2>Nhận định đối chiếu</h2></div>
            <div className="comparison-criteria">
              {(validSites[0]?.audit?.findings || []).map(finding => <article className="comparison-criterion" key={finding.id}>
                <strong>{finding.ten}</strong>
                <div className="comparison-scores">
                  {validSites.map((site, index) => {
                    const siteFinding = site.audit?.findings.find(item => item.id === finding.id);
                    return <div className="comparison-score" key={`${site.domain}-${index}`}>
                      <span>{index === 0 ? "Website khách" : "Đối thủ"} · {site.domain}</span>
                      <b>{scoreText(siteFinding)}</b>
                    </div>;
                  })}
                </div>
              </article>)}
            </div>
            {comparison.ketLuan.length > 0 && <div>
              <h3>Nhận xét tổng hợp</h3>
              <ul style={{ display: "grid", gap: 8, padding: 0, listStyle: "none" }}>
                {comparison.ketLuan.map((line, index) => {
                  const separator = line.indexOf(": ");
                  const group = separator >= 0 ? line.slice(0, separator) : line;
                  const detail = separator >= 0 ? line.slice(separator + 2) : "";
                  return <li key={index} style={{ border: "1px solid #eadfca", borderRadius: 10, background: "#fffdf8", padding: "10px 14px" }}>
                    <strong style={{ display: "block" }}>{group}</strong>
                    {detail && <span>{detail}</span>}
                  </li>;
                })}
              </ul>
            </div>}
          </section>
          <section className="panel stack">
            <div><p className="eyebrow">ĐỐI CHIẾU TIÊU CHÍ</p><h2 style={{ color: "#b42318" }}>Thua ở {lost.length} chỗ</h2></div>
            {lost.length ? lost.slice(0, 5).map(item => renderDifference(item, false)) : <p>Không có tiêu chí nào mà website khách đạt ít điểm hơn đối thủ.</p>}
          </section>
          <section className="panel stack">
            <div><p className="eyebrow">ĐỐI CHIẾU TIÊU CHÍ</p><h2 style={{ color: "#18794e" }}>Hơn ở {won.length} chỗ</h2></div>
            {won.length ? won.slice(0, 5).map(item => renderDifference(item, false)) : <p>Không có tiêu chí nào mà website khách đạt nhiều điểm hơn đối thủ.</p>}
          </section>
        </>
        : <p className="notice">Chưa đủ hai website tải thành công để đối chiếu.</p>}
    </>}
  </div>;
}
