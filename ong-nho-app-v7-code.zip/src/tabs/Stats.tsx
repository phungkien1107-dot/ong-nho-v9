import { useEffect, useMemo, useState, type ReactNode } from "react";
import { connectStats, loadStats, type AuditResult, type StatsMetricRow, type StatsResult } from "../api";
import { getChecks, getSiteKey } from "../lib/history";
import Bee from "../ui/Bee";

const GA_PROPERTIES_KEY = "ong-nho-ga-properties";
type GaProperties = Record<string, string>;

function formatNumber(value: number | null | undefined): string {
  return value === null || value === undefined ? "—" : new Intl.NumberFormat("vi-VN", { maximumFractionDigits: 2 }).format(value);
}

function formatCell(value: number | null, kind: "percent" | "plain" = "plain"): string {
  if (value === null) return "—";
  return `${formatNumber(value)}${kind === "percent" ? "%" : ""}`;
}

function siteScore(rows: StatsResult["summary"]): number | null {
  if (!rows.ctr || !rows.position) return null;
  const ctr = Math.min(rows.ctr.value / 5, 1) * 100;
  const position = rows.position.value <= 3 ? 100 : rows.position.value <= 10 ? 70 : rows.position.value <= 20 ? 40 : 20;
  return (ctr + position) / 2;
}

function MetricTable({ rows, keyword = false }: { rows: StatsMetricRow[]; keyword?: boolean }) {
  return <div className="table-scroll" role="region" aria-label={keyword ? "Bảng từ khóa, có thể cuộn ngang" : "Bảng số liệu, có thể cuộn ngang"} tabIndex={0}>
    <table style={{ width: "100%", borderCollapse: "collapse", textAlign: "left", fontSize: 13 }}>
      <thead><tr>{(keyword
        ? ["Từ khóa", "Clicks", "Impressions", "CTR", "Vị trí"]
        : ["Tên", "Clicks", "Impressions", "CTR", "Vị trí"]).map(label =>
        <th key={label} style={{ padding: 9, borderBottom: "1px solid #eadfca", whiteSpace: "nowrap" }}>{label}</th>)}</tr></thead>
      <tbody>{rows.map((row, index) => <tr key={`${row.key}-${index}`}>
        <td style={{ padding: 9, borderBottom: "1px solid #f1e9db" }}>{row.key}</td>
        <td style={cellStyle}>{formatCell(row.clicks)}</td>
        <td style={cellStyle}>{formatCell(row.impressions)}</td>
        <td style={cellStyle}>{formatCell(row.ctr, "percent")}</td>
        <td style={cellStyle}>{formatCell(row.position)}</td>
      </tr>)}</tbody>
    </table>
    {!rows.length && <p className="subtle">Chưa có dữ liệu cho mục này.</p>}
  </div>;
}

const cellStyle = { padding: 9, borderBottom: "1px solid #f1e9db", whiteSpace: "nowrap" as const };

function Section({ title, children }: { title: string; children: ReactNode }) {
  return <section className="panel stack"><h3 style={{ margin: 0 }}>{title}</h3>{children}</section>;
}

function highImpressionRows(data: StatsResult): StatsMetricRow[] {
  const commonCtr = data.summary.ctr?.value;
  const sorted = data.queries.filter(row => row.impressions !== null).sort((a, b) => (b.impressions || 0) - (a.impressions || 0));
  if (commonCtr === undefined || !sorted.length) return [];
  const median = sorted[Math.floor((sorted.length - 1) / 2)].impressions || 0;
  return sorted.filter(row => (row.impressions || 0) >= median && row.ctr !== null && row.ctr < commonCtr).slice(0, 5);
}

function deviceRows(rows: StatsMetricRow[]): StatsMetricRow[] {
  const words = ["điện thoại", "mobile", "phone", "máy tính", "desktop", "computer", "tablet", "máy tính bảng"];
  return rows.filter(row => words.some(word => row.key.toLocaleLowerCase("vi").includes(word)));
}

function hostFromSiteKey(value: string): string {
  try {
    const raw = value.trim();
    const host = raw.startsWith("sc-domain:")
      ? raw.slice("sc-domain:".length)
      : new URL(/^[a-z][a-z\d+.-]*:\/\//i.test(raw) ? raw : `https://${raw}`).hostname;
    return host.toLowerCase().replace(/^www\./, "");
  } catch {
    return "";
  }
}

function analyticsSiteKey(input: string): string {
  try {
    const raw = input.trim();
    const parsed = new URL(/^[a-z][a-z\d+.-]*:\/\//i.test(raw) ? raw : `https://${raw}`);
    return parsed.hostname.toLowerCase().replace(/^www\./, "");
  } catch {
    return "";
  }
}

export default function Stats() {
  const [url, setUrl] = useState("");
  const [siteKey, setSiteKey] = useState("");
  const [data, setData] = useState<StatsResult>();
  const [checkScore, setCheckScore] = useState<number | null>(null);
  const [connected, setConnected] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [gaProperties, setGaProperties] = useState<GaProperties>({});
  const [analyticsProperty, setAnalyticsProperty] = useState("");
  const [gaStorageError, setGaStorageError] = useState("");

  useEffect(() => {
    try {
      const saved = localStorage.getItem(GA_PROPERTIES_KEY);
      if (saved) {
        const parsed = JSON.parse(saved) as Record<string, unknown>;
        setGaProperties(Object.fromEntries(Object.entries(parsed).filter(
          (entry): entry is [string, string] => typeof entry[1] === "string" && /^\d+$/.test(entry[1])
        )));
      }
    } catch {
      setGaStorageError("Không đọc được property ID đã lưu trên trình duyệt này.");
    }
  }, []);

  useEffect(() => {
    setAnalyticsProperty(gaProperties[analyticsSiteKey(url)] || "");
  }, [url, gaProperties]);

  const joinedScore = useMemo(() => {
    const measured = data ? siteScore(data.summary) : null;
    return measured !== null && checkScore !== null ? (measured + checkScore) / 2 : null;
  }, [data, checkScore]);
  const lowClickRows = data ? highImpressionRows(data) : [];
  const devices = data ? deviceRows(data.devices) : [];
  const keywords = data ? [...data.queries].sort((a, b) => (b.clicks || 0) - (a.clicks || 0)).slice(0, 50) : [];
  const propertyId = analyticsProperty.trim();
  const validPropertyId = /^\d+$/.test(propertyId);
  const analyticsUrl = validPropertyId
    ? `https://analytics.google.com/analytics/web/#/p${encodeURIComponent(propertyId)}/reports/intelligenthome`
    : "https://analytics.google.com/analytics/web/";
  const searchConsoleUrl = (() => {
    if (!url.trim()) return "";
    try {
      const parsed = new URL(/^[a-z][a-z\d+.-]*:\/\//i.test(url.trim()) ? url.trim() : `https://${url.trim()}`);
      const host = parsed.hostname.toLowerCase().replace(/^www\./, "");
      const key = data?.site === host
        ? data.selectedKey
        : hostFromSiteKey(siteKey) === host ? siteKey.trim() : `sc-domain:${host}`;
      const target = new URL("https://search.google.com/search-console/performance/search-analytics");
      target.searchParams.set("resource_id", key);
      return target.toString();
    } catch {
      return "";
    }
  })();

  async function connect() {
    setBusy(true);
    setError("");
    setMessage("");
    try {
      const result = await connectStats();
      setConnected(result.connected);
      setMessage(result.message);
    } catch (reason) {
      setConnected(false);
      setError(reason instanceof Error ? reason.message : "Không kết nối được với Chrome.");
    } finally { setBusy(false); }
  }

  async function load() {
    if (!url.trim()) { setError("Nhập địa chỉ website đã có trong Search Console."); return; }
    setBusy(true);
    setError("");
    setMessage("");
    setData(undefined);
    setCheckScore(null);
    try {
      const result = await loadStats(url.trim(), siteKey.trim());
      setData(result);
      setConnected(result.connected);
      const history = await getChecks();
      const match = history.find(row => row.siteKey === getSiteKey(url.trim()));
      setCheckScore(match?.audit.score ?? null);
      setMessage(result.diagnostic || "");
    } catch (reason) {
      const text = reason instanceof Error ? reason.message : "Không đọc được số liệu website.";
      setError(text);
      if (text.includes("đăng nhập Google")) setConnected(false);
    } finally { setBusy(false); }
  }

  function updateAnalyticsProperty(value: string) {
    setAnalyticsProperty(value);
    setGaStorageError("");
    if (value.trim() && !/^\d+$/.test(value.trim())) {
      setGaStorageError("Property ID phải chỉ gồm chữ số; giá trị chưa được lưu.");
      return;
    }
    const key = analyticsSiteKey(url);
    if (!key) return;
    const updated = { ...gaProperties };
    if (value.trim()) updated[key] = value.trim();
    else delete updated[key];
    try {
      localStorage.setItem(GA_PROPERTIES_KEY, JSON.stringify(updated));
      setGaProperties(updated);
    } catch {
      setGaStorageError("Không lưu được property ID trên trình duyệt này.");
    }
  }

  return <div className="stack">
    <section className="panel stack">
      <div className="section-title"><div><p className="eyebrow">SEARCH CONSOLE VÀ ANALYTICS</p><h2>Thống kê website</h2></div></div>
      <div className="actions">
        <button className="button secondary" onClick={connect} disabled={busy}>{busy ? "Đang kết nối…" : "Kết nối"}</button>
      </div>
      <label className="field">Địa chỉ website
        <input value={url} onChange={event => setUrl(event.target.value)} placeholder="https://tenmien.vn" style={inputStyle} />
      </label>
      <div className="actions">
        <a className="button secondary" href={searchConsoleUrl || undefined} target={searchConsoleUrl ? "_blank" : undefined} rel="noreferrer"
          aria-disabled={!searchConsoleUrl} onClick={event => { if (!searchConsoleUrl) event.preventDefault(); }}>Google Search Console</a>
        <a className="button secondary" href={url.trim() ? analyticsUrl : undefined} target={url.trim() ? "_blank" : undefined} rel="noreferrer"
          aria-disabled={!url.trim()} onClick={event => { if (!url.trim()) event.preventDefault(); }}>Google Analytics</a>
      </div>
      <label className="field">Google Analytics property ID
        <input value={analyticsProperty} onChange={event => updateAnalyticsProperty(event.target.value)} placeholder="Ví dụ: 123456789" inputMode="numeric"
          list="saved-ga-properties" style={inputStyle} disabled={!analyticsSiteKey(url)} />
        <datalist id="saved-ga-properties">{Object.entries(gaProperties).map(([host, id]) =>
          <option value={id} label={`${id} · ${host}`} key={`${host}-${id}`} />)}</datalist>
      </label>
      {gaStorageError
        ? <p className="notice error" role="alert">{gaStorageError}</p>
        : <p className="subtle">{validPropertyId
          ? `Property ID đã lưu riêng cho ${analyticsSiteKey(url)}; nút Analytics mở property này.`
          : "Chưa có property ID cho website này. Nhập hoặc chọn ID để mở đúng property; nếu để trống, nút sẽ mở Analytics chung."}</p>}
      <label className="field">Khóa site Search Console (không bắt buộc)
        <input value={siteKey} onChange={event => setSiteKey(event.target.value)} placeholder="sc-domain:tenmien.vn hoặc https://tenmien.vn/" style={inputStyle} />
      </label>
      <button className="button" onClick={load} disabled={busy || !connected}>{busy ? "Đang đọc số liệu…" : "Xem số liệu website"}</button>
      {message && <p className="notice" role="status">{message}</p>}
      {error && <p className="notice error" role="alert">{error} Kiểm tra kết nối và quyền truy cập rồi thử lại nhé.</p>}
    </section>

    {busy && <section className="panel loading-panel" role="status" aria-live="polite" aria-busy="true">
      <span className="bee-flight"><Bee small /></span><div><p className="eyebrow">ĐANG TẢI SỐ LIỆU</p><strong>Đợi Ong Nhỏ một chút nhé…</strong><div className="progress-track"><span /></div></div>
    </section>}
    {!data && !busy && !error && <div className="empty panel"><Bee small /><h2>Số liệu đang chờ bạn</h2><p>Kết nối Google, chọn website rồi xem thống kê.</p></div>}
    {data && <>
      <section className="result-head">
        <div className="result-meta"><p className="eyebrow">{data.green ? "🟢 WEBSITE CÓ DỮ LIỆU" : "🔴 CHƯA ĐỌC ĐƯỢC DỮ LIỆU"}</p>
          <h2>{data.site}</h2><p>{data.period}</p><p className="subtle">Khóa đã mở: {data.selectedKey}</p></div>
      </section>
      {data.diagnostic && <p className="notice error" role="alert">{data.diagnostic} Kiểm tra tài khoản và quyền truy cập rồi thử lại nhé.</p>}
      {data.messages.map((item, index) => <p className="notice" key={`${item}-${index}`}>{item}</p>)}
      {!data.green && <p className="notice">Chưa có số liệu cho khoảng thời gian này. Chọn website khác hoặc thử lại sau nhé.</p>}
      {data.green && <>
        <section className="metric-row" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(170px,1fr))", gap: 12 }}>
          {[
            ["Clicks", data.summary.clicks?.display],
            ["Impressions", data.summary.impressions?.display],
            ["CTR", data.summary.ctr?.display],
            ["Vị trí trung bình", data.summary.position?.display]
          ].map(([label, value]) => <article className="panel" key={label} style={{ padding: 16 }}>
            <p className="eyebrow">{label}</p><strong style={{ fontSize: 25 }}>{value || "—"}</strong><p className="subtle">{data.period}</p>
          </article>)}
        </section>
        <Section title="Nhận định">
          {data.nhanDinh.map((line, index) => <p key={index} style={{ margin: 0 }}>{line}</p>)}
        </Section>
        <Section title="Đang hiển thị nhiều nhưng ít người bấm">
          <MetricTable rows={lowClickRows} />
        </Section>
        <Section title="Thống kê thiết bị">
          <MetricTable rows={devices} />
          {data.nhanDinhThietBi.map((line, index) => <p key={index} style={{ margin: 0 }}>{line}</p>)}
        </Section>
        <Section title="Điểm ghép">
          <strong style={{ fontSize: 32 }}>{joinedScore === null ? "—" : `${joinedScore}/100`}</strong>
          <p style={{ margin: 0 }}>Điểm kiểm tra: {checkScore === null ? "chưa có" : `${checkScore}/100`} · Điểm số liệu: {siteScore(data.summary) === null ? "chưa có" : `${siteScore(data.summary)}/100`}.</p>
          {checkScore === null && <p style={{ margin: 0 }}>Chưa có điểm kiểm tra cho website này</p>}
          {siteScore(data.summary) !== null && <p className="subtle" style={{ margin: 0 }}>Công thức: điểm số liệu = trung bình của min(CTR/5%, 1) × 100 và điểm vị trí (≤3: 100; ≤10: 70; ≤20: 40; còn lại: 20); điểm ghép = (điểm kiểm tra + điểm số liệu) / 2.</p>}
        </Section>
        <Section title="Từ khóa">
          <MetricTable rows={keywords} keyword />
        </Section>
        <details className="panel">
          <summary style={{ cursor: "pointer", fontWeight: 700 }}>Xem nâng cao</summary>
          <div className="stack" style={{ marginTop: 16 }}>
            <Section title="Trang"><MetricTable rows={data.pages} /></Section>
            <Section title="Quốc gia"><MetricTable rows={data.countries} /></Section>
            <Section title="Giao diện tìm kiếm"><MetricTable rows={data.searchAppearance} /></Section>
          </div>
        </details>
      </>}
    </>}
  </div>;
}

const inputStyle = { display: "block", width: "100%", height: 42, marginTop: 7, borderRadius: 9, border: "1px solid #e2d7c3", background: "#fff", padding: "0 10px" };
