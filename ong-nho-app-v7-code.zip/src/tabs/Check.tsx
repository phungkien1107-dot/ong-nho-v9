import { useEffect, useMemo, useState, type FormEvent } from "react";
import { checkSite, checkSpelling, type AuditResult, type Finding } from "../api";
import { getLatestCheck, saveCheck, type SavedCheck } from "../lib/history";
import { playBee } from "../lib/sound";
import Bee from "../ui/Bee";
import Gauge from "../ui/Gauge";
import Shot from "../ui/Shot";

const steps = ["Đang mở website…", "Đang chấm điểm…", "Đang chuẩn bị ảnh…"];
const visualIds: Record<number, string> = { 3: "h1", 5: "anh_alt", 21: "cta", 25: "dieu_huong" };

export default function Check({ soundEnabled = true }: { soundEnabled?: boolean }) {
  const [url, setUrl] = useState("");
  const [result, setResult] = useState<AuditResult>();
  const [spellingIssues, setSpellingIssues] = useState<Array<{ tuSai: string; cauChuaTu: string }>>([]);
  const [spellingImages, setSpellingImages] = useState<Array<{ tuSai: string; anh: string; rect: { id: string; x: number; y: number; w: number; h: number } }>>([]);
  const [spellingState, setSpellingState] = useState<"idle" | "busy" | "done">("idle");
  const [spellingError, setSpellingError] = useState("");
  const [previous, setPrevious] = useState<SavedCheck | null>(null);
  const [busy, setBusy] = useState(false);
  const [phase, setPhase] = useState(0);
  const [pdfBusy, setPdfBusy] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!busy) return;
    setPhase(0);
    const timer = window.setInterval(() => setPhase(value => (value + 1) % steps.length), 900);
    return () => window.clearInterval(timer);
  }, [busy]);

  const sortedFindings = useMemo(() => result
    ? [...result.findings].sort((a, b) => {
      const scoreA = a.trangThai === "khong_ap_dung" ? Number.POSITIVE_INFINITY : a.diemDat / Math.max(1, a.diemToiDa);
      const scoreB = b.trangThai === "khong_ap_dung" ? Number.POSITIVE_INFINITY : b.diemDat / Math.max(1, b.diemToiDa);
      return scoreA - scoreB || a.id - b.id;
    })
    : [], [result]);
  async function submit(event: FormEvent) {
    event.preventDefault();
    setError("");
    setResult(undefined);
    setSpellingIssues([]);
    setSpellingImages([]);
    setSpellingState("idle");
    setSpellingError("");
    setPrevious(null);
    setBusy(true);
    try {
      const audit = await checkSite(url.trim());
      const prior = await getLatestCheck(audit.page.finalUrl);
      setPrevious(prior);
      setResult(audit);
      playBee(soundEnabled);
      await saveCheck(audit);
    } catch (reason) {
      setError(friendlyError(reason));
    } finally {
      setBusy(false);
    }
  }

  async function runSpellingCheck() {
    if (!result) return;
    setSpellingState("busy");
    setSpellingError("");
    setSpellingIssues([]);
    setSpellingImages([]);
    try {
      const response = await checkSpelling(result.page.finalUrl);
      setSpellingIssues(response.issues);
      setSpellingImages(response.images);
      setSpellingState("done");
    } catch (reason) {
      setSpellingError(reason instanceof Error ? reason.message : "Không thể kiểm tra chính tả.");
      setSpellingState("idle");
    }
  }

  async function exportPdf() {
    if (!result) return;
    setPdfBusy(true);
    setError("");
    try {
      const response = await fetch("/api/pdf", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ audit: result, previous })
      });
      if (!response.ok) {
        const data = await response.json().catch(() => ({}));
        throw new Error(typeof data.error === "string" ? data.error : "Không tạo được báo cáo PDF.");
      }
      const blob = await response.blob();
      const href = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = href;
      link.download = "ong-nho-bao-cao.pdf";
      link.click();
      window.setTimeout(() => URL.revokeObjectURL(href), 1000);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Không tạo được báo cáo PDF.");
    } finally {
      setPdfBusy(false);
    }
  }

  const changes = previous && result ? compareResults(previous.audit, result) : null;
  const openUrl = externalUrl(url);
  return <div className="stack">
    <form className="panel check-form" onSubmit={submit}>
      <label htmlFor="site-url">Địa chỉ website</label>
      <div className="input-row">
        <input id="site-url" type="text" inputMode="url" required placeholder="https://tenmien.vn" value={url} onChange={event => setUrl(event.target.value)} />
        <button className="button" type="submit" disabled={busy}>{busy ? "Đang kiểm tra…" : "Kiểm tra ngay"}</button>
      </div>
      {url.trim() && <a className="button secondary" href={openUrl || "#"} target={openUrl ? "_blank" : undefined} rel={openUrl ? "noreferrer" : undefined}
        onClick={event => { if (!openUrl) { event.preventDefault(); setError("Địa chỉ website chưa hợp lệ."); } }}
        style={{ marginTop: 9, padding: "8px 12px" }}>Mở website</a>}
      <p className="hint">Bạn có thể kiểm tra website công khai dùng HTTP hoặc HTTPS.</p>
    </form>

    {busy && <section className="panel loading-panel" aria-live="polite" aria-busy="true">
      <span className="bee-flight"><Bee small /></span>
      <div><p className="eyebrow">ĐANG QUÉT WEBSITE</p><strong>{steps[phase]}</strong>
        <div className="progress-track" role="progressbar" aria-label="Tiến trình kiểm tra"><span /></div>
      </div>
    </section>}
    {error && <p className="notice error" role="alert">{error} Bạn kiểm tra lại địa chỉ và thử thêm lần nữa nhé.</p>}

    {result && <>
      {result.loiAI && <p className="notice error" role="status">{result.loiAI} Bạn vẫn xem được điểm; thử lại sau nhé.</p>}
      {result.loiChup && <p className="notice" role="status">{typeof result.loiChup === "string" ? result.loiChup : "Ảnh chụp chưa sẵn sàng."} Bạn vẫn xem được điểm.</p>}
      <div className="actions"><button className="button" type="button" onClick={exportPdf} disabled={pdfBusy} aria-label={pdfBusy ? "Đang tạo báo cáo PDF" : "Xuất báo cáo PDF"}>{pdfBusy ? "Đang tạo PDF…" : "Xuất PDF"}</button></div>
      <section className="result-head">
        <Gauge value={result.score} />
        <div className="result-meta">
          <p className="eyebrow">ĐIỂM TỔNG THỂ</p>
          <h2>{result.title || "Chưa có tiêu đề trang"}</h2>
          <span className={`score-caption ${result.score >= 80 ? "good" : result.score < 50 ? "bad" : "warn"}`}>
            {result.score >= 80 ? "Rất ổn" : result.score < 50 ? "Cần ưu tiên" : "Đang cải thiện"}
          </span>
          <p><a href={result.page.finalUrl} target="_blank" rel="noreferrer">{result.page.finalUrl}</a></p>
          <div className="metric-row"><span>Mã phản hồi <b>{result.page.status}</b></span><span>Phản hồi <b>{result.page.durationMs} ms</b></span><span>HTML <b>{Math.round(result.page.bytes / 1024)} KB</b></span></div>
        </div>
      </section>

      <section className="panel">
        <div className="section-title"><div><p className="eyebrow">ĐIỂM THEO NHÓM</p><h2>5 nhóm tiêu chí</h2></div></div>
        <div className="group-scores" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(180px,1fr))", gap: 14, marginTop: 18 }}>{result.groupScores.map(group => <div className="group-score" style={{ display: "grid", gap: 7 }} key={group.nhom}>
          <span>{group.nhom}</span><b>{group.diem}<small> / {group.diemToiDa}</small></b>
          <div style={{ height: 6, background: "#f0e7d6", borderRadius: 9, overflow: "hidden" }}><span style={{ display: "block", height: "100%", width: `${group.diemToiDa ? group.diem / group.diemToiDa * 100 : 0}%`, background: "#FFB400" }} /></div>
        </div>)}</div>
      </section>

      <section className="panel">
        <div className="section-title"><div><p className="eyebrow">KẾT QUẢ CHI TIẾT</p><h2>25 tiêu chí · điểm thấp đến cao</h2></div></div>
        <div className="stack" style={{ gap: 10 }}>
          {sortedFindings.map((item, index) => <FindingRow key={item.id} item={item} result={result} index={index} />)}
        </div>
      </section>

      <section className="panel">
        <p className="eyebrow">NHẬN XÉT TỔNG QUAN</p>
        <div className="review-grid" style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(240px,1fr))", gap: 20 }}>
          <div><h3>3 điểm mạnh</h3><ReviewList result={result} strong empty="Chưa có nhận xét cho phần này." /></div>
          <div><h3>3 điểm còn yếu</h3><ReviewList result={result} strong={false} empty="Chưa có nhận xét cho phần này." /></div>
        </div>
      </section>

      <section className="panel">
        <p className="eyebrow">VĂN BẢN TRANG</p><h3>Kiểm tra chính tả</h3>
        <button className="button secondary" type="button" onClick={runSpellingCheck} disabled={spellingState === "busy"}>
          {spellingState === "busy" ? "Đang kiểm tra chính tả…" : "Kiểm tra chính tả"}
        </button>
        {spellingError && <p className="notice error" role="alert">{spellingError}</p>}
        {spellingState === "done" && (spellingIssues.length
          ? <ol>{spellingIssues.map((issue, index) => {
            const image = spellingImages.find(item => item.tuSai === issue.tuSai);
            return <li key={`${issue.tuSai}-${index}`}><b>{issue.tuSai}</b> · {issue.cauChuaTu}
              {image && <Shot anh={image.anh} rects={[image.rect]} startNumber={index + 1} tone="bad"
                ghiChu={[{ id: index + 1, ten: issue.tuSai, tinhTrang: issue.cauChuaTu, tone: "bad" }]} />}
            </li>;
          })}</ol>
          : <p className="notice" role="status">Trang không có lỗi chính tả</p>)}
      </section>

      {result.docAnh && <section className="panel"><p className="eyebrow">ẤN TƯỢNG KHI MỞ TRANG</p><p>{result.docAnh}</p></section>}
      {result.canhBaoJS && <p className="notice" role="status"><b>Nội dung có thể được tạo bằng JavaScript.</b> {result.giaiThichJS}</p>}
      {previous && changes && <BeforeAfter previous={previous} current={result} changes={changes} />}
    </>}

    {!result && !busy && <div className="empty panel"><span className="empty-bee"><Bee small /></span><h2>Sẵn sàng kiểm tra</h2><p>Nhập địa chỉ website ở trên để bắt đầu nhé.</p></div>}
  </div>;
}

function FindingRow({ item, result, index }: { item: Finding; result: AuditResult; index: number }) {
  const status = item.trangThai === "khong_ap_dung"
    ? { label: "Không áp dụng", tone: "na", icon: "—" }
    : item.trangThai === "dat"
      ? { label: "Tốt", tone: "good", icon: "✓" }
      : item.trangThai === "mot_phan"
        ? { label: "Cần cải thiện", tone: "warn", icon: "!" }
        : { label: "Lỗi", tone: "bad", icon: "×" };
  return <article className="finding" style={{ display: "block", animationDelay: `${Math.min(index, 12) * 30}ms` }}>
    <div style={{ display: "flex", alignItems: "flex-start", gap: 11 }}>
      <span className={`status-dot ${status.tone}`} aria-hidden="true">{status.icon}</span>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: "flex", justifyContent: "space-between", gap: 8, flexWrap: "wrap" }}>
          <h3>{String(item.id).padStart(2, "0")} · {item.ten}</h3>
          <span className={`status-chip ${status.tone}`}><span aria-hidden="true">{status.icon}</span>{status.label}</span>
        </div>
        <p className="finding-score">{item.trangThai === "khong_ap_dung" ? "Không tính điểm" : `${item.diemDat} / ${item.diemToiDa} điểm`}</p>
        <p>{item.tinhTrang}</p><p>{item.yNghia}</p>
        <FindingImage item={item} result={result} />
      </div>
    </div>
  </article>;
}

function FindingImage({ item, result }: { item: Finding; result: AuditResult }) {
  if (item.trangThai === "khong_ap_dung") return null;
  const tone = item.trangThai === "dat" ? "good" : item.trangThai === "mot_phan" ? "partial" : "bad";
  const extra = result.anhPhu?.find(image => image.id === item.id);
  if (extra) return <Shot anh={extra.anh} rects={extra.rects} tone={tone}
    ghiChu={extra.rects.map((rect, index) => ({
      id: index + 1,
      ten: item.ten,
      tinhTrang: `${item.tinhTrang}${rect.approximate ? " · chưa xác định chính xác vị trí." : ""}`,
      tone
    }))} />;
  const id = visualIds[item.id];
  const marks = item.rect ? Array.isArray(item.rect) ? item.rect : [item.rect] : id ? result.rects.filter(rect => rect.id === id) : [];
  return <div>
    {marks.length > 0 && result.anh
      ? <Shot anh={result.anh} rects={marks} tone={tone}
        ghiChu={marks.map((rect, index) => ({
          id: index + 1,
          ten: item.ten,
          tinhTrang: `${item.tinhTrang}${rect.approximate ? " · chưa xác định chính xác vị trí." : ""}`,
          tone
        }))} />
      : <div className="image-note">
        Ảnh đánh dấu chưa có; nội dung có thể nằm thấp hơn trên trang hoặc không được tìm thấy.
      </div>}
  </div>;
}

function auditNotes(result: AuditResult, rects: AuditResult["rects"]): Array<{ id: number; ten: string; tinhTrang: string; tone: "good" | "partial" | "bad" }> {
  return rects.map((rect, index) => {
    const finding = result.findings.find(item => visualIds[item.id] === rect.id);
    const tone: "good" | "partial" | "bad" = finding?.trangThai === "dat" ? "good" : finding?.trangThai === "chua_dat" ? "bad" : "partial";
    return {
      id: index + 1,
      ten: finding?.ten || rect.id,
      tinhTrang: `${finding?.tinhTrang || "Vùng được khoanh trong ảnh."}${rect.approximate ? " · chưa xác định chính xác vị trí." : ""}`,
      tone
    };
  });
}

type ChangeSet = {
  score: number;
  groups: Array<{ name: string; delta: number }>;
  better: string[];
  worse: string[];
};

function compareResults(before: AuditResult, after: AuditResult): ChangeSet {
  const groups = after.groupScores.map(group => ({
    name: group.nhom,
    delta: group.diem - (before.groupScores.find(item => item.nhom === group.nhom)?.diem ?? 0)
  })).filter(group => group.delta !== 0);
  const better: string[] = [];
  const worse: string[] = [];
  for (const item of after.findings) {
    const old = before.findings.find(previousItem => previousItem.id === item.id);
    if (!old || old.diemDat === item.diemDat) continue;
    (item.diemDat > old.diemDat ? better : worse).push(item.ten);
  }
  return { score: after.score - before.score, groups, better, worse };
}

function BeforeAfter({ previous, current, changes }: { previous: SavedCheck; current: AuditResult; changes: ChangeSet }) {
  const changed = changes.score !== 0 || changes.groups.length > 0 || changes.better.length > 0 || changes.worse.length > 0;
  return <section className="panel stack">
    <div><p className="eyebrow">SO SÁNH LỊCH SỬ</p><h2>Trước và sau</h2></div>
    {!changed ? <p className="notice">Chưa có thay đổi so với lần trước</p> : <>
      <p>Điểm tổng thể: {previous.audit.score}/100 → {current.score}/100 ({changes.score > 0 ? "+" : ""}{changes.score} điểm)</p>
      {changes.groups.length > 0 && <div><b>Điểm nhóm thay đổi</b><ul>{changes.groups.map(group => <li key={group.name}>{group.name}: {group.delta > 0 ? "+" : ""}{group.delta} điểm</li>)}</ul></div>}
      {changes.better.length > 0 && <div><b>Tiêu chí tăng điểm</b><p>{changes.better.join(" · ")}</p></div>}
      {changes.worse.length > 0 && <div><b>Tiêu chí giảm điểm</b><p>{changes.worse.join(" · ")}</p></div>}
    </>}
    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(240px,1fr))", gap: 14 }}>
      <div><h3>Lần trước · {new Date(previous.createdAt).toLocaleString("vi-VN")}</h3>
        {previous.audit.anh ? <Shot anh={previous.audit.anh} rects={previous.audit.rects} ghiChu={auditNotes(previous.audit, previous.audit.rects)} /> : <p className="subtle">Lần trước không có ảnh lưu.</p>}
      </div>
      <div><h3>Lần này</h3>
        {current.anh ? <Shot anh={current.anh} rects={current.rects} ghiChu={auditNotes(current, current.rects)} /> : <p className="subtle">Lần này không có ảnh chụp.</p>}
      </div>
    </div>
  </section>;
}

function reviewLines(result: AuditResult, strong: boolean): string[] {
  const aiLines = strong ? result.nhanXet?.diemManh : result.nhanXet?.diemYeu;
  if (aiLines?.length) return aiLines.slice(0, 3);
  return rankedFindings(result, strong).slice(0, 3)
    .map(item => `${item.ten}: ${item.tinhTrang}.`);
}

function rankedFindings(result: AuditResult, strong: boolean): Finding[] {
  return result.findings.filter(item => item.diemToiDa > 0 && item.trangThai !== "khong_ap_dung")
    .sort((a, b) => strong
      ? b.diemDat / b.diemToiDa - a.diemDat / a.diemToiDa
      : a.diemDat / a.diemToiDa - b.diemDat / b.diemToiDa);
}

function ReviewList({ result, strong, empty }: { result: AuditResult; strong: boolean; empty: string }) {
  const lines = reviewLines(result, strong);
  const links = result.nhanXet?.tieuChiLienQuan?.[strong ? "diemManh" : "diemYeu"] || [];
  const ranked = rankedFindings(result, strong);
  if (!lines.length) return <p className="subtle">{empty}</p>;
  return <ul>{lines.map((line, index) => {
    const linked = (links[index] || []).map(id => result.findings.find(item => item.id === id)).filter((item): item is Finding => Boolean(item));
    const related = linked.length ? linked : ranked[index] ? [ranked[index]] : [];
    return <li key={`${index}-${line}`}>{line}
      {related.length
        ? related.map(item => <FindingImage key={item.id} item={item} result={result} />)
        : <p className="subtle">Chưa có tiêu chí liên quan.</p>}
    </li>;
  })}</ul>;
}

function externalUrl(value: string): string | null {
  const trimmed = value.trim();
  if (!trimmed) return null;
  try {
    const url = new URL(/^[a-z][a-z\d+.-]*:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`);
    return ["http:", "https:"].includes(url.protocol) ? url.toString() : null;
  } catch {
    return null;
  }
}

function friendlyError(reason: unknown): string {
  const detail = reason instanceof Error ? reason.message : "";
  if (/địa chỉ|website|http|url/i.test(detail) && /không hợp lệ|không tìm thấy|quá nhiều|không tải|không kết nối/i.test(detail)) return detail;
  if (/timeout|timed out|quá thời gian/i.test(detail)) return "Website phản hồi quá lâu, kết quả chưa sẵn sàng.";
  return "Không thể hoàn tất kiểm tra. Kiểm tra địa chỉ website và kết nối mạng.";
}
