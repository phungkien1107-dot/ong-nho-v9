export type Rect = { id: string; x: number; y: number; w: number; h: number; approximate?: boolean };
export type Finding = {
  id: number;
  nhom: string;
  ten: string;
  diemToiDa: number;
  diemDat: number;
  trangThai: "dat" | "mot_phan" | "chua_dat" | "khong_ap_dung";
  tinhTrang: string;
  yNghia: string;
  nhinThay: boolean;
  rect?: Rect | Rect[];
  name: string;
  status: "tốt" | "chú ý";
  meaning: string;
  points: number;
};
export type AuditResult = {
  score: number;
  title: string;
  findings: Finding[];
  page: { url: string; finalUrl: string; status: number; durationMs: number; bytes: number; compressedBytes: number | null; compression: string; html: string };
  groupScores: Array<{ nhom: string; diem: number; diemToiDa: number }>;
  canhBaoJS: boolean;
  giaiThichJS: string;
  anh: string | null;
  rects: Rect[];
  loiChup?: string;
  nhanXet: {
    diemManh: string[];
    diemYeu: string[];
    tieuChiLienQuan?: { diemManh: number[][]; diemYeu: number[][] };
  };
  loiChinhTa: Array<{ tuSai: string; cauChuaTu: string }>;
  anhPhu?: Array<{ id: number; anh: string; rects: Rect[] }>;
  anhChinhTa?: Array<{ tuSai: string; anh: string; rect: Rect }>;
  docAnh: string;
  loiAI: string;
  ghiChu: Array<{ id: number; ten: string; tinhTrang: string }>;
};
export type StatsNumber = { value: number; display: string };
export type StatsMetricRow = { key: string; clicks: number | null; impressions: number | null; ctr: number | null; position: number | null };
export type StatsResult = {
  connected: boolean;
  site: string;
  selectedKey: string;
  green: boolean;
  period: string;
  summary: { clicks: StatsNumber | null; impressions: StatsNumber | null; ctr: StatsNumber | null; position: StatsNumber | null };
  queries: StatsMetricRow[];
  pages: StatsMetricRow[];
  devices: StatsMetricRow[];
  countries: StatsMetricRow[];
  searchAppearance: StatsMetricRow[];
  ga: Array<{ label: string; value: string }>;
  gaDiagnostic?: string;
  messages: string[];
  diagnostic?: string;
  nhanDinh: string[];
  nhanDinhThietBi: string[];
};
async function request<T>(path: string, body?: unknown): Promise<T> {
  const response = await fetch(path, { method: body === undefined ? "GET" : "POST", headers: body === undefined ? {} : { "content-type": "application/json" }, body: body === undefined ? undefined : JSON.stringify(body) });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Không thể hoàn tất yêu cầu.");
  return data as T;
}
export const checkSite = (url: string) => request<AuditResult>("/api/check", { url });
export const checkSpelling = (url: string) =>
  request<{ issues: Array<{ tuSai: string; cauChuaTu: string }>; images: Array<{ tuSai: string; anh: string; rect: Rect }> }>("/api/spelling", { url });
export const askAi = (audit: AuditResult) => request<{ summary: string }>("/api/ai", audit);
export const askImage = (image: string) => request<{ summary: string }>("/api/ai/image", { image });
export const captureSite = (url: string, findings: Finding[]) => request<{ image: string; pdf: string }>("/api/shot", { url, findings });
export const connectStats = () => request<{ connected: boolean; message: string }>("/api/stats/connect", {});
export const loadStats = (url: string, siteKey = "") => request<StatsResult>("/api/stats/data", { url, siteKey });
export const logoutStats = () => request<{ message: string }>("/api/stats/logout", {});
