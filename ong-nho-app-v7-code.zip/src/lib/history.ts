import type { AuditResult } from "../api";

const STORAGE_KEY = "ong-nho-history";
const DB_NAME = "ong-nho-history";
const STORE = "images";
const IMAGES_PER_SITE = 5;

export type SavedCheck = { id: string; siteKey: string; createdAt: string; audit: AuditResult };
type ImageRecord = {
  id: string;
  siteKey: string;
  createdAt: string;
  image: string | null;
  anhPhu?: AuditResult["anhPhu"];
  anhChinhTa?: AuditResult["anhChinhTa"];
};
function siteKey(input: string): string {
  try {
    const url = new URL(/^[a-z][a-z\d+.-]*:\/\//i.test(input) ? input : `https://${input}`);
    const host = url.hostname.toLowerCase().replace(/^www\./, "");
    const path = url.pathname.toLowerCase().replace(/\/+$/, "") || "/";
    return `${host}${path}`;
  } catch {
    return input.trim().toLowerCase().replace(/^https?:\/\//, "").replace(/^www\./, "").replace(/\/+$/, "");
  }
}

function loadRows(): SavedCheck[] {
  try {
    const value = localStorage.getItem(STORAGE_KEY);
    return value ? JSON.parse(value) as SavedCheck[] : [];
  } catch {
    return [];
  }
}

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => request.result.createObjectStore(STORE, { keyPath: "id" });
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function imageRows(): Promise<ImageRecord[]> {
  const db = await openDatabase();
  try {
    return await new Promise((resolve, reject) => {
      const request = db.transaction(STORE).objectStore(STORE).getAll();
      request.onsuccess = () => resolve(request.result as ImageRecord[]);
      request.onerror = () => reject(request.error);
    });
  } finally { db.close(); }
}

async function removeImages(ids: string[]): Promise<void> {
  if (!ids.length) return;
  const db = await openDatabase();
  try {
    await new Promise<void>((resolve, reject) => {
      const transaction = db.transaction(STORE, "readwrite");
      const store = transaction.objectStore(STORE);
      ids.forEach(id => store.delete(id));
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error);
      transaction.onabort = () => reject(transaction.error);
    });
  } finally { db.close(); }
}

async function saveImage(record: ImageRecord): Promise<void> {
  const existing = await imageRows();
  const sameSite = existing.filter(item => item.siteKey === record.siteKey).sort((a, b) => a.createdAt.localeCompare(b.createdAt));
  const obsolete = sameSite.slice(0, Math.max(0, sameSite.length - IMAGES_PER_SITE + 1));
  await removeImages(obsolete.map(item => item.id));
  for (;;) {
    const db = await openDatabase();
    try {
      await new Promise<void>((resolve, reject) => {
        const transaction = db.transaction(STORE, "readwrite");
        transaction.objectStore(STORE).put(record);
        transaction.oncomplete = () => resolve();
        transaction.onerror = () => reject(transaction.error);
        transaction.onabort = () => reject(transaction.error);
      });
      return;
    } catch (error) {
      if (!(error instanceof DOMException) || error.name !== "QuotaExceededError") return;
      const remaining = (await imageRows()).filter(item => item.id !== record.id).sort((a, b) => a.createdAt.localeCompare(b.createdAt));
      if (!remaining.length) return;
      await removeImages([remaining[0].id]);
    } finally { db.close(); }
  }
}

async function pruneSiteImages(site: string, rows: SavedCheck[]): Promise<void> {
  const recent = rows.filter(row => row.siteKey === site).sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, IMAGES_PER_SITE);
  const allowed = new Set(recent.map(row => row.id));
  const images = await imageRows();
  await removeImages(images.filter(item => item.siteKey === site && !allowed.has(item.id)).map(item => item.id));
}

async function hydrate(rows: SavedCheck[]): Promise<SavedCheck[]> {
  let images: ImageRecord[] = [];
  try { images = await imageRows(); } catch { /* Lịch sử điểm vẫn khả dụng nếu IndexedDB không mở được. */ }
  const byId = new Map(images.map(item => [item.id, item]));
  return rows.map(row => {
    const saved = byId.get(row.id);
    return {
      ...row,
      audit: {
        ...row.audit,
        anh: saved?.image || null,
        anhPhu: saved?.anhPhu || [],
        anhChinhTa: saved?.anhChinhTa || []
      }
    };
  });
}

export async function saveCheck(audit: AuditResult): Promise<SavedCheck | null> {
  const createdAt = new Date().toISOString();
  const id = typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`;
  const key = siteKey(audit.page.finalUrl || audit.page.url);
  const row: SavedCheck = {
    id,
    siteKey: key,
    createdAt,
    audit: {
      ...audit,
      anh: null,
      anhPhu: [],
      anhChinhTa: [],
      page: { ...audit.page, html: "" }
    } as AuditResult
  };
  try {
    const rows = loadRows();
    localStorage.setItem(STORAGE_KEY, JSON.stringify([row, ...rows]));
    if (audit.anh || audit.anhPhu?.length || audit.anhChinhTa?.length) {
      await saveImage({
        id, siteKey: key, createdAt, image: audit.anh,
        anhPhu: audit.anhPhu, anhChinhTa: audit.anhChinhTa
      });
    }
    try { await pruneSiteImages(key, [row, ...rows]); } catch { /* Điểm vẫn được lưu dù ảnh không còn khả dụng. */ }
    return {
      ...row,
      audit: { ...row.audit, anh: audit.anh || null, anhPhu: audit.anhPhu || [], anhChinhTa: audit.anhChinhTa || [] }
    };
  } catch {
    return { ...row, audit: { ...row.audit, anh: null, anhPhu: [], anhChinhTa: [] } };
  }
}

export async function getChecks(): Promise<SavedCheck[]> {
  const rows = loadRows().sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  return hydrate(rows);
}

export async function getLatestCheck(url: string): Promise<SavedCheck | null> {
  const key = siteKey(url);
  const row = loadRows().filter(item => item.siteKey === key).sort((a, b) => b.createdAt.localeCompare(a.createdAt))[0];
  if (!row) return null;
  return (await hydrate([row]))[0];
}

export async function deleteSiteHistory(key: string): Promise<void> {
  const rows = loadRows().filter(row => row.siteKey !== key);
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(rows)); } catch { /* Lịch sử đang mở vẫn có thể được làm mới. */ }
  try {
    const images = await imageRows();
    await removeImages(images.filter(item => item.siteKey === key).map(item => item.id));
  } catch { /* Điểm đã được xóa khỏi lịch sử trên trình duyệt. */ }
}

export async function clearChecks(): Promise<void> {
  try { localStorage.removeItem(STORAGE_KEY); } catch { /* Không có dữ liệu localStorage để xóa. */ }
  try {
    const images = await imageRows();
    await removeImages(images.map(item => item.id));
  } catch { /* Không có ảnh IndexedDB để xóa. */ }
}

export function getSiteKey(url: string): string {
  return siteKey(url);
}
