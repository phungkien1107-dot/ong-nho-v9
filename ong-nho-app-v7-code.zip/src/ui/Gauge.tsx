import { useEffect, useState } from "react";

export default function Gauge({ value }: { value: number }) {
  const score = Math.max(0, Math.min(100, Math.round(value)));
  const [shown, setShown] = useState(0);
  const [ringScore, setRingScore] = useState(0);
  const tone = score >= 80 ? "good-score" : score >= 50 ? "mid-score" : "low-score";
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setRingScore(score);
      return;
    }
    let frame = 0;
    frame = requestAnimationFrame(() => setRingScore(score));
    return () => cancelAnimationFrame(frame);
  }, [score]);
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setShown(score);
      return;
    }
    let frame = 0;
    const started = performance.now();
    const animate = (now: number) => {
      const progress = Math.min(1, (now - started) / 1400);
      const smooth = 1 - (1 - progress) ** 3;
      setShown(Math.round(score * smooth));
      if (progress < 1) frame = requestAnimationFrame(animate);
    };
    frame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(frame);
  }, [score]);
  const circumference = 2 * Math.PI * 43;
  return <div className={`gauge ${tone}`} style={{ background: "none" }} role="img" aria-label={`Điểm tổng thể ${shown} trên 100`}>
    <svg viewBox="0 0 100 100" aria-hidden="true" style={{ position: "absolute", inset: 0, width: "100%", height: "100%", zIndex: 1, transform: "rotate(-90deg)" }}>
      <circle cx="50" cy="50" r="43" fill="none" stroke="#f0e7d6" strokeWidth="8" />
      <circle cx="50" cy="50" r="43" fill="none" stroke="var(--gauge-color)" strokeWidth="8" strokeLinecap="round"
        strokeDasharray={circumference} strokeDashoffset={circumference * (1 - ringScore / 100)}
        style={{ transition: "stroke-dashoffset 1.4s cubic-bezier(.2,.8,.2,1)" }} />
    </svg>
    <div className="gauge-inner" style={{ position: "relative", zIndex: 2, flexDirection: "column", alignItems: "center", gap: 0 }}>
      <strong>{shown}</strong><span>/ 100</span>
    </div>
  </div>;
}
