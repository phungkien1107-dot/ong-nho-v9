import { useId } from "react";

export default function Bee({ small = false }: { small?: boolean }) {
  const id = "bee" + useId().replace(/:/g, "");
  return <span className={`bee ${small ? "bee-small" : ""}`} role="img" aria-label="Ong Nhỏ">
    <svg viewBox="215 40 250 285" aria-hidden="true">
      <defs><clipPath id={id}><ellipse cx="340" cy="205" rx="108" ry="96" /></clipPath></defs>
      <g className="wing-l"><ellipse cx="285" cy="110" rx="42" ry="68" transform="rotate(-28 285 110)" fill="#E3F3FC" stroke="#8EC5E3" strokeWidth="4" /></g>
      <g className="wing-r"><ellipse cx="395" cy="110" rx="42" ry="68" transform="rotate(28 395 110)" fill="#E3F3FC" stroke="#8EC5E3" strokeWidth="4" /></g>
      <path d="M318 122 Q305 80 288 62" fill="none" stroke="#3B2412" strokeWidth="5" strokeLinecap="round" />
      <circle cx="288" cy="60" r="8" fill="#FFC83D" stroke="#3B2412" strokeWidth="4" />
      <path d="M362 122 Q375 80 392 62" fill="none" stroke="#3B2412" strokeWidth="5" strokeLinecap="round" />
      <circle cx="392" cy="60" r="8" fill="#FFC83D" stroke="#3B2412" strokeWidth="4" />
      <path d="M334 300 L340 320 L346 300Z" fill="#3B2412" />
      <ellipse cx="305" cy="306" rx="14" ry="7" fill="#3B2412" />
      <ellipse cx="375" cy="306" rx="14" ry="7" fill="#3B2412" />
      <ellipse cx="340" cy="205" rx="108" ry="96" fill="#FFC83D" />
      <g clipPath={`url(#${id})`}><rect x="220" y="250" width="240" height="20" fill="#3B2412" /><rect x="220" y="282" width="240" height="30" fill="#3B2412" /></g>
      <ellipse cx="340" cy="205" rx="108" ry="96" fill="none" stroke="#3B2412" strokeWidth="5" />
      <path d="M284 166 Q302 160 320 166" fill="none" stroke="#3B2412" strokeWidth="5" strokeLinecap="round" />
      <path d="M352 152 Q378 140 404 154" fill="none" stroke="#3B2412" strokeWidth="5" strokeLinecap="round" />
      <ellipse cx="302" cy="190" rx="12" ry="14" fill="#2A1A0C" /><circle cx="306" cy="184" r="4.5" fill="#fff" /><circle cx="298" cy="196" r="2" fill="#fff" />
      <ellipse cx="378" cy="190" rx="12" ry="14" fill="#2A1A0C" /><circle cx="382" cy="184" r="4.5" fill="#fff" /><circle cx="374" cy="196" r="2" fill="#fff" />
      <circle cx="378" cy="190" r="29" fill="#fff" fillOpacity=".28" stroke="#C99A1E" strokeWidth="5" />
      <path d="M358 176 Q364 166 374 163" fill="none" stroke="#fff" strokeWidth="4" strokeLinecap="round" />
      <path d="M401 212 Q442 232 430 272" fill="none" stroke="#A9770C" strokeWidth="4" strokeDasharray="1 8" strokeLinecap="round" />
      <ellipse cx="274" cy="224" rx="14" ry="8" fill="#FF8FA3" fillOpacity=".75" />
      <ellipse cx="412" cy="236" rx="12" ry="8" fill="#FF8FA3" fillOpacity=".75" />
      <path d="M326 224 Q340 240 354 224" fill="none" stroke="#3B2412" strokeWidth="5" strokeLinecap="round" />
    </svg>
  </span>;
}
