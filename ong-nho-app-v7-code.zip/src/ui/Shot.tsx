type Rect = { id: string; x: number; y: number; w: number; h: number };
type Tone = "good" | "partial" | "bad";
type Note = { id: number; ten: string; tinhTrang: string; tone?: Tone };
type Props = {
  anh?: string | null;
  rects?: Rect[];
  ghiChu?: Note[];
  image?: string;
  pdf?: string;
  onAi?: () => void;
  summary?: string;
  busy?: boolean;
  tone?: Tone;
  startNumber?: number;
};

const labels: Record<string, string> = {
  h1: "Tiêu đề chính",
  h2: "Tiêu đề phụ",
  noi_dung: "Nội dung trang",
  anh_alt: "Ảnh thiếu alt",
  cta: "Nút hành động",
  lien_he: "Thông tin liên hệ",
  tel: "Liên kết gọi điện",
  chinh_ta: "Lỗi chính tả",
  dieu_huong: "Điều hướng"
};

const toneColors: Record<Tone, string> = { good: "#168447", partial: "#1769aa", bad: "#c53030" };

export default function Shot({ anh, rects = [], ghiChu = [], image, pdf, onAi, summary, busy = false, tone = "partial", startNumber = 1 }: Props) {
  const source = anh ? `data:image/jpeg;base64,${anh}` : image || "";
  if (!source) return null;
  return <section className="panel shot-panel">
    <h3>Ảnh minh họa website</h3>
    <div className="shot-layout" style={{ display: "flex", flexWrap: "wrap", gap: 16, alignItems: "flex-start" }}>
      <div className="shot-image-frame" style={{ position: "relative", flex: "3 1 540px", minWidth: 0, aspectRatio: "1366 / 800", overflow: "hidden", background: "#FFF8E7" }}>
        <img src={source.startsWith("data:") ? source : `data:image/png;base64,${source}`} alt="Ảnh website có vùng được đánh dấu" loading="lazy" decoding="async" style={{ display: "block", width: "100%", height: "100%", objectFit: "contain" }} />
        {rects.map((rect, index) => <div key={`${rect.id}-${index}`} title={labels[rect.id] || rect.id} style={{
          position: "absolute", left: `${rect.x}%`, top: `${rect.y}%`, width: `${rect.w}%`, height: `${rect.h}%`,
          border: `3px solid ${toneColors[ghiChu[index]?.tone || tone]}`, borderRadius: 6, boxSizing: "border-box", pointerEvents: "none"
        }}>
          <span style={{ position: "absolute", top: -1, left: -1, minWidth: 23, height: 23, display: "grid", placeItems: "center", borderRadius: "50%", background: toneColors[ghiChu[index]?.tone || tone], color: "#fff", fontSize: 14, fontWeight: 800, lineHeight: 1 }}>{startNumber + index}</span>
        </div>)}
      </div>
      <aside aria-label="Phân tích các vùng được đánh dấu" style={{ flex: "1 1 220px", minWidth: 0, display: "grid", gap: 8, maxHeight: 450, overflowY: "auto" }}>
        {ghiChu.length > 0 && <strong style={{ fontSize: 14 }}>Phân tích vùng được đánh dấu</strong>}
        {ghiChu.length
          ? ghiChu.map((note, index) => <div key={`${note.id}-${index}`} style={{ padding: 10, border: "1px solid #eadfca", borderRadius: 9, background: "#fffdf8", fontSize: 14, lineHeight: 1.5 }}>
            <b style={{ color: toneColors[note.tone || tone] }}>{startNumber + index}. {note.ten}</b><div style={{ marginTop: 4, color: "#514638" }}>{note.tinhTrang}</div>
          </div>)
          : <p style={{ margin: 0, color: "#514638", fontSize: 14 }}>Không tìm thấy vùng phù hợp để đánh dấu.</p>}
      </aside>
    </div>
    <p style={{ color: "#514638", fontSize: 13, margin: "10px 0" }}>Số trên ảnh tương ứng với số thứ tự trong phần phân tích.</p>
    {(pdf || onAi) && <div className="actions">
      {pdf && <a className="button secondary" aria-label="Tải báo cáo PDF" href={`data:application/pdf;base64,${pdf}`} download="bao-cao-ong-nho.pdf">Tải báo cáo PDF</a>}
      {onAi && <button className="button secondary" type="button" aria-label={busy ? "Đang đọc ảnh" : "Đọc ảnh bằng AI"} onClick={onAi} disabled={busy}>{busy ? "Đang đọc ảnh…" : "Đọc ảnh bằng AI"}</button>}
    </div>}
    {summary && <p className="ai-summary">{summary}</p>}
  </section>;
}
